CREATE TABLE IF NOT EXISTS public.school_years (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT false,
  passing_score NUMERIC NOT NULL DEFAULT 50,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT school_year_dates_valid CHECK (start_date <= end_date),
  CONSTRAINT school_year_passing_score_valid CHECK (passing_score >= 0 AND passing_score <= 100)
);

ALTER TABLE public.school_years ENABLE ROW LEVEL SECURITY;

CREATE UNIQUE INDEX IF NOT EXISTS school_years_single_active_idx
ON public.school_years (is_active)
WHERE is_active = true;

CREATE POLICY "Authenticated can read school years"
ON public.school_years
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admin can insert school years"
ON public.school_years
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admin can update school years"
ON public.school_years
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admin can delete school years"
ON public.school_years
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role));

ALTER TABLE public.classes
  ADD COLUMN IF NOT EXISTS school_year_id UUID REFERENCES public.school_years(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS promotion_order INTEGER NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS classes_school_year_id_idx ON public.classes(school_year_id);
CREATE INDEX IF NOT EXISTS classes_promotion_order_idx ON public.classes(promotion_order);
CREATE UNIQUE INDEX IF NOT EXISTS classes_name_per_year_idx
ON public.classes(school_year_id, nom)
WHERE school_year_id IS NOT NULL;

ALTER TABLE public.students
  ADD COLUMN IF NOT EXISTS school_year_id UUID REFERENCES public.school_years(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS current_class_id UUID REFERENCES public.classes(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS students_school_year_id_idx ON public.students(school_year_id);
CREATE INDEX IF NOT EXISTS students_current_class_id_idx ON public.students(current_class_id);

ALTER TABLE public.grades
  ADD COLUMN IF NOT EXISTS school_year_id UUID REFERENCES public.school_years(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS grades_school_year_id_idx ON public.grades(school_year_id);

ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS school_year_id UUID REFERENCES public.school_years(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS transactions_school_year_id_idx ON public.transactions(school_year_id);

ALTER TABLE public.courses
  ADD COLUMN IF NOT EXISTS max_note NUMERIC NOT NULL DEFAULT 20;

ALTER TABLE public.payment_types
  ADD COLUMN IF NOT EXISTS default_amount NUMERIC NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS public.fee_structures (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  school_year_id UUID NOT NULL REFERENCES public.school_years(id) ON DELETE CASCADE,
  class_id UUID REFERENCES public.classes(id) ON DELETE CASCADE,
  payment_type_id UUID REFERENCES public.payment_types(id) ON DELETE SET NULL,
  label TEXT NOT NULL,
  amount NUMERIC NOT NULL DEFAULT 0,
  is_mandatory BOOLEAN NOT NULL DEFAULT true,
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT fee_structures_amount_valid CHECK (amount >= 0)
);

ALTER TABLE public.fee_structures ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS fee_structures_school_year_id_idx ON public.fee_structures(school_year_id);
CREATE INDEX IF NOT EXISTS fee_structures_class_id_idx ON public.fee_structures(class_id);
CREATE INDEX IF NOT EXISTS fee_structures_payment_type_id_idx ON public.fee_structures(payment_type_id);

CREATE POLICY "Authenticated can read fee structures"
ON public.fee_structures
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Admin/comptable can insert fee structures"
ON public.fee_structures
FOR INSERT
TO authenticated
WITH CHECK (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
);

CREATE POLICY "Admin/comptable can update fee structures"
ON public.fee_structures
FOR UPDATE
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
);

CREATE POLICY "Admin/comptable can delete fee structures"
ON public.fee_structures
FOR DELETE
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
);

CREATE TABLE IF NOT EXISTS public.student_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id UUID NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  class_id UUID REFERENCES public.classes(id) ON DELETE SET NULL,
  school_year_id UUID REFERENCES public.school_years(id) ON DELETE SET NULL,
  status TEXT NOT NULL,
  average NUMERIC,
  next_class_name TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  CONSTRAINT student_history_status_valid CHECK (status IN ('promoted', 'repeated', 'transferred')),
  CONSTRAINT student_history_unique_student_year UNIQUE (student_id, school_year_id)
);

ALTER TABLE public.student_history ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS student_history_student_id_idx ON public.student_history(student_id);
CREATE INDEX IF NOT EXISTS student_history_school_year_id_idx ON public.student_history(school_year_id);
CREATE INDEX IF NOT EXISTS student_history_class_id_idx ON public.student_history(class_id);

CREATE POLICY "Admin/secretaire/comptable can read student history"
ON public.student_history
FOR SELECT
TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'secretaire'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
);

CREATE POLICY "Admin can insert student history"
ON public.student_history
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admin can update student history"
ON public.student_history
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE OR REPLACE FUNCTION public.set_active_school_year(_school_year_id UUID)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  UPDATE public.school_years
  SET is_active = false
  WHERE is_active = true
    AND id <> _school_year_id;

  UPDATE public.school_years
  SET is_active = true
  WHERE id = _school_year_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.preview_student_promotions(
  _source_school_year_id UUID,
  _target_school_year_id UUID,
  _passing_score NUMERIC DEFAULT 50
)
RETURNS TABLE (
  student_id UUID,
  student_name TEXT,
  current_class_id UUID,
  current_class_name TEXT,
  next_class_id UUID,
  next_class_name TEXT,
  average_percent NUMERIC,
  status TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  RETURN QUERY
  WITH student_averages AS (
    SELECT
      s.id AS student_id,
      s.nom AS student_name,
      s.current_class_id,
      c.nom AS current_class_name,
      c.section AS current_section,
      c.promotion_order,
      COALESCE(
        ROUND(
          AVG(
            CASE
              WHEN COALESCE(cr.max_note, 20) > 0 THEN (g.note / COALESCE(cr.max_note, 20)) * 100
              ELSE 0
            END
          )::NUMERIC,
          2
        ),
        0
      ) AS average_percent
    FROM public.students s
    LEFT JOIN public.classes c ON c.id = s.current_class_id
    LEFT JOIN public.grades g
      ON g.eleve_id = s.id
     AND (g.school_year_id = _source_school_year_id OR g.school_year_id IS NULL)
    LEFT JOIN public.courses cr ON cr.id = g.cours_id
    WHERE COALESCE(s.school_year_id, _source_school_year_id) = _source_school_year_id
    GROUP BY s.id, s.nom, s.current_class_id, c.nom, c.section, c.promotion_order
  ),
  decisions AS (
    SELECT
      sa.*,
      CASE WHEN sa.average_percent >= _passing_score THEN 'promoted' ELSE 'repeated' END AS status,
      CASE WHEN sa.average_percent >= _passing_score THEN COALESCE(sa.promotion_order, 0) + 1 ELSE COALESCE(sa.promotion_order, 0) END AS target_order
    FROM student_averages sa
  )
  SELECT
    d.student_id,
    d.student_name,
    d.current_class_id,
    d.current_class_name,
    tc.id AS next_class_id,
    tc.nom AS next_class_name,
    d.average_percent,
    d.status
  FROM decisions d
  LEFT JOIN public.classes tc
    ON tc.school_year_id = _target_school_year_id
   AND tc.promotion_order = d.target_order
   AND COALESCE(tc.section, '') = COALESCE(d.current_section, '')
  ORDER BY d.current_class_name NULLS LAST, d.student_name;
END;
$$;

CREATE OR REPLACE FUNCTION public.apply_student_promotions(
  _source_school_year_id UUID,
  _target_school_year_id UUID,
  _passing_score NUMERIC DEFAULT 50
)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _updated_count INTEGER := 0;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  INSERT INTO public.student_history (student_id, class_id, school_year_id, status, average, next_class_name)
  SELECT
    p.student_id,
    p.current_class_id,
    _source_school_year_id,
    p.status,
    p.average_percent,
    COALESCE(p.next_class_name, '')
  FROM public.preview_student_promotions(_source_school_year_id, _target_school_year_id, _passing_score) p
  ON CONFLICT (student_id, school_year_id)
  DO UPDATE SET
    class_id = EXCLUDED.class_id,
    status = EXCLUDED.status,
    average = EXCLUDED.average,
    next_class_name = EXCLUDED.next_class_name;

  UPDATE public.students s
  SET
    school_year_id = _target_school_year_id,
    current_class_id = COALESCE(p.next_class_id, s.current_class_id),
    classe = COALESCE(p.next_class_name, s.classe)
  FROM public.preview_student_promotions(_source_school_year_id, _target_school_year_id, _passing_score) p
  WHERE s.id = p.student_id;

  GET DIAGNOSTICS _updated_count = ROW_COUNT;
  RETURN _updated_count;
END;
$$;