-- Add archived flag to school_years
ALTER TABLE public.school_years
  ADD COLUMN IF NOT EXISTS is_archived boolean NOT NULL DEFAULT false;

-- Helper RPC: archive a school year (admin only). Cannot archive the active year.
CREATE OR REPLACE FUNCTION public.archive_school_year(_school_year_id uuid, _archive boolean DEFAULT true)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  IF _archive THEN
    IF EXISTS (SELECT 1 FROM public.school_years WHERE id = _school_year_id AND is_active = true) THEN
      RAISE EXCEPTION 'Impossible d''archiver l''année active';
    END IF;
  END IF;

  UPDATE public.school_years
  SET is_archived = _archive,
      updated_at = now()
  WHERE id = _school_year_id;
END;
$$;