-- school_years: lecture restreinte aux 3 rôles
DROP POLICY IF EXISTS "Authenticated can read school years" ON public.school_years;
CREATE POLICY "Staff can read school years"
ON public.school_years FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'secretaire'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
);

-- fee_structures
DROP POLICY IF EXISTS "Authenticated can read fee structures" ON public.fee_structures;
CREATE POLICY "Staff can read fee structures"
ON public.fee_structures FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
  OR public.has_role(auth.uid(), 'secretaire'::public.app_role)
);

-- classes
DROP POLICY IF EXISTS "Authenticated can read classes" ON public.classes;
CREATE POLICY "Staff can read classes"
ON public.classes FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'secretaire'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
);

-- courses
DROP POLICY IF EXISTS "Authenticated can read courses" ON public.courses;
CREATE POLICY "Staff can read courses"
ON public.courses FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'secretaire'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
);

-- payment_types
DROP POLICY IF EXISTS "Authenticated can read payment_types" ON public.payment_types;
CREATE POLICY "Staff can read payment_types"
ON public.payment_types FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'admin'::public.app_role)
  OR public.has_role(auth.uid(), 'comptable'::public.app_role)
  OR public.has_role(auth.uid(), 'secretaire'::public.app_role)
);