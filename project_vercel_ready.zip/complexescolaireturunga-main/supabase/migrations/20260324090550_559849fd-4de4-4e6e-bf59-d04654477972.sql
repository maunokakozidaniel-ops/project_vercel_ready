
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS matricule text UNIQUE;

CREATE OR REPLACE FUNCTION public.generate_matricule()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = 'public'
AS $$
DECLARE
  year_part text;
  seq_num integer;
  new_matricule text;
BEGIN
  year_part := to_char(now(), 'YYYY');
  SELECT COUNT(*) + 1 INTO seq_num FROM public.students WHERE matricule LIKE 'CST-' || year_part || '-%';
  new_matricule := 'CST-' || year_part || '-' || LPAD(seq_num::text, 4, '0');
  NEW.matricule := new_matricule;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_generate_matricule
BEFORE INSERT ON public.students
FOR EACH ROW
WHEN (NEW.matricule IS NULL OR NEW.matricule = '')
EXECUTE FUNCTION public.generate_matricule();
