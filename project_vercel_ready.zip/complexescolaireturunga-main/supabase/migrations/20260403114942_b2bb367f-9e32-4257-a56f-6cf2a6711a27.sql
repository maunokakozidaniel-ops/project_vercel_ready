
-- Fix security: restrict SELECT on sensitive tables to appropriate roles

-- Drop overly permissive SELECT policies
DROP POLICY IF EXISTS "Authenticated can read teachers" ON public.teachers;
DROP POLICY IF EXISTS "Authenticated can read personnel" ON public.personnel;
DROP POLICY IF EXISTS "Authenticated can read transactions" ON public.transactions;
DROP POLICY IF EXISTS "Authenticated can read students" ON public.students;
DROP POLICY IF EXISTS "Authenticated can read grades" ON public.grades;

-- Teachers: readable by admin and secretaire only
CREATE POLICY "Admin/secretaire can read teachers" ON public.teachers
FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));

-- Personnel: readable by admin and comptable only
CREATE POLICY "Admin/comptable can read personnel" ON public.personnel
FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'comptable'::app_role));

-- Transactions: readable by admin and comptable only
CREATE POLICY "Admin/comptable can read transactions" ON public.transactions
FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'comptable'::app_role));

-- Students: readable by admin and secretaire only
CREATE POLICY "Admin/secretaire can read students" ON public.students
FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));

-- Grades: readable by admin and secretaire only
CREATE POLICY "Admin/secretaire can read grades" ON public.grades
FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));
