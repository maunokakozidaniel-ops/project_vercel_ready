
-- Fix security: scope "Users can view their own roles" to authenticated only
DROP POLICY IF EXISTS "Users can view their own roles" ON public.user_roles;
CREATE POLICY "Users can view their own roles" ON public.user_roles
FOR SELECT TO authenticated
USING (auth.uid() = user_id);

-- Allow comptable to read students
DROP POLICY IF EXISTS "Admin/secretaire can read students" ON public.students;
CREATE POLICY "Admin/secretaire/comptable can read students" ON public.students
FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'secretaire'::app_role) OR 
  has_role(auth.uid(), 'comptable'::app_role)
);

-- Allow comptable to read teachers
DROP POLICY IF EXISTS "Admin/secretaire can read teachers" ON public.teachers;
CREATE POLICY "Admin/secretaire/comptable can read teachers" ON public.teachers
FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role) OR 
  has_role(auth.uid(), 'secretaire'::app_role) OR 
  has_role(auth.uid(), 'comptable'::app_role)
);

-- Allow comptable to read personnel (already has access, but let's keep it)
-- Already: Admin/comptable can read personnel - OK

-- Allow comptable to read classes (already public for authenticated)
-- Already: Authenticated can read classes - OK
