
-- Restrict teachers reads to admin/secretaire only (remove comptable)
DROP POLICY IF EXISTS "Admin/secretaire/comptable can read teachers" ON public.teachers;
CREATE POLICY "Admin/secretaire can read teachers"
ON public.teachers FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));

-- Fix profiles policies to apply to authenticated only
DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;

CREATE POLICY "Users can insert own profile"
ON public.profiles FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
ON public.profiles FOR UPDATE TO authenticated
USING (auth.uid() = user_id);
