
-- 1) Restrict school_settings SELECT to staff roles only
DROP POLICY IF EXISTS "Authenticated can read settings" ON public.school_settings;
CREATE POLICY "Staff can read settings"
ON public.school_settings
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR has_role(auth.uid(), 'secretaire'::app_role)
  OR has_role(auth.uid(), 'comptable'::app_role)
);

-- 2) Revoke EXECUTE on admin-only SECURITY DEFINER functions from public/anon
REVOKE EXECUTE ON FUNCTION public.copy_school_year_data(uuid, uuid, boolean, boolean, boolean, boolean) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.preview_student_promotions(uuid, uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.apply_student_promotions(uuid, uuid, numeric) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.set_active_school_year(uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.archive_school_year(uuid, boolean) FROM PUBLIC, anon;
