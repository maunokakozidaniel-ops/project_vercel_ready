
-- Add new columns to students
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS adresse text NOT NULL DEFAULT '';
ALTER TABLE public.students ADD COLUMN IF NOT EXISTS tel_parent text NOT NULL DEFAULT '';

-- Add new columns to teachers
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS statut text NOT NULL DEFAULT 'actif';
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS adresse text NOT NULL DEFAULT '';
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS salaire numeric NOT NULL DEFAULT 0;
ALTER TABLE public.teachers ADD COLUMN IF NOT EXISTS genre text NOT NULL DEFAULT 'M';

-- Add new columns to personnel
ALTER TABLE public.personnel ADD COLUMN IF NOT EXISTS date_naissance text NOT NULL DEFAULT '';
ALTER TABLE public.personnel ADD COLUMN IF NOT EXISTS genre text NOT NULL DEFAULT 'M';
ALTER TABLE public.personnel ADD COLUMN IF NOT EXISTS departement text NOT NULL DEFAULT '';
ALTER TABLE public.personnel ADD COLUMN IF NOT EXISTS adresse text NOT NULL DEFAULT '';
ALTER TABLE public.personnel ADD COLUMN IF NOT EXISTS statut text NOT NULL DEFAULT 'actif';

-- Create classes table
CREATE TABLE IF NOT EXISTS public.classes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nom text NOT NULL,
  section text NOT NULL DEFAULT '',
  capacite integer NOT NULL DEFAULT 50,
  titulaire text NOT NULL DEFAULT '',
  annee_scolaire text NOT NULL DEFAULT '2025-2026',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.classes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read classes" ON public.classes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admin/secretaire can insert classes" ON public.classes FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));
CREATE POLICY "Admin/secretaire can update classes" ON public.classes FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));
CREATE POLICY "Admin/secretaire can delete classes" ON public.classes FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));

-- Create timetables table
CREATE TABLE IF NOT EXISTS public.timetables (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  classe text NOT NULL,
  jour text NOT NULL,
  heure_debut text NOT NULL,
  heure_fin text NOT NULL,
  cours text NOT NULL,
  enseignant text NOT NULL DEFAULT '',
  salle text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.timetables ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read timetables" ON public.timetables FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admin/secretaire can insert timetables" ON public.timetables FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));
CREATE POLICY "Admin/secretaire can update timetables" ON public.timetables FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));
CREATE POLICY "Admin/secretaire can delete timetables" ON public.timetables FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'secretaire'::app_role));

-- Add UPDATE policy to transactions (was missing)
CREATE POLICY "Admin/comptable can update transactions" ON public.transactions FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'comptable'::app_role));

-- Add triggers for updated_at
CREATE TRIGGER update_classes_updated_at BEFORE UPDATE ON public.classes FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_timetables_updated_at BEFORE UPDATE ON public.timetables FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
