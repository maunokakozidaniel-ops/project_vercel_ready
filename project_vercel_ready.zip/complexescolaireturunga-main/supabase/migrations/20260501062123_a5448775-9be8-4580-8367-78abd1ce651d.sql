CREATE OR REPLACE FUNCTION public.copy_school_year_data(
  _source_id uuid,
  _target_id uuid,
  _copy_classes boolean DEFAULT true,
  _copy_courses boolean DEFAULT true,
  _copy_fees boolean DEFAULT true,
  _copy_students boolean DEFAULT false
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _count integer := 0;
  _added integer := 0;
  _target_year text;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  IF _source_id = _target_id THEN
    RAISE EXCEPTION 'Source and target must differ';
  END IF;

  SELECT name INTO _target_year FROM public.school_years WHERE id = _target_id;

  -- Classes
  IF _copy_classes THEN
    WITH ins AS (
      INSERT INTO public.classes (nom, section, capacite, titulaire, annee_scolaire, school_year_id, promotion_order)
      SELECT c.nom, c.section, c.capacite, c.titulaire, COALESCE(_target_year, c.annee_scolaire), _target_id, c.promotion_order
      FROM public.classes c
      WHERE c.school_year_id = _source_id
        AND NOT EXISTS (
          SELECT 1 FROM public.classes c2
          WHERE c2.school_year_id = _target_id AND c2.nom = c.nom AND COALESCE(c2.section,'') = COALESCE(c.section,'')
        )
      RETURNING 1
    ) SELECT count(*) INTO _added FROM ins;
    _count := _count + _added;
  END IF;

  -- Courses (no school_year_id column on courses; copy unique by name+classe if missing)
  IF _copy_courses THEN
    WITH ins AS (
      INSERT INTO public.courses (nom, coefficient, enseignant, classe, max_note)
      SELECT DISTINCT c.nom, c.coefficient, c.enseignant, c.classe, c.max_note
      FROM public.courses c
      WHERE NOT EXISTS (
        SELECT 1 FROM public.courses c2 WHERE c2.nom = c.nom AND c2.classe = c.classe
      )
      RETURNING 1
    ) SELECT count(*) INTO _added FROM ins;
    _count := _count + _added;
  END IF;

  -- Fee structures
  IF _copy_fees THEN
    WITH ins AS (
      INSERT INTO public.fee_structures (label, amount, payment_type_id, class_id, school_year_id, is_mandatory, notes)
      SELECT f.label, f.amount, f.payment_type_id, f.class_id, _target_id, f.is_mandatory, f.notes
      FROM public.fee_structures f
      WHERE f.school_year_id = _source_id
        AND NOT EXISTS (
          SELECT 1 FROM public.fee_structures f2
          WHERE f2.school_year_id = _target_id AND f2.label = f.label
            AND COALESCE(f2.class_id::text,'') = COALESCE(f.class_id::text,'')
        )
      RETURNING 1
    ) SELECT count(*) INTO _added FROM ins;
    _count := _count + _added;
  END IF;

  -- Re-attach students to target year (keep same class)
  IF _copy_students THEN
    WITH upd AS (
      UPDATE public.students s
      SET school_year_id = _target_id
      WHERE s.school_year_id = _source_id
      RETURNING 1
    ) SELECT count(*) INTO _added FROM upd;
    _count := _count + _added;
  END IF;

  RETURN _count;
END;
$$;