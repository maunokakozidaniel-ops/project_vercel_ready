
CREATE TABLE public.payment_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  label text NOT NULL,
  direction text NOT NULL DEFAULT 'in',
  color text NOT NULL DEFAULT 'bg-green-100 text-green-800',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.payment_types ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read payment_types" ON public.payment_types FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admin/comptable can insert payment_types" ON public.payment_types FOR INSERT TO authenticated WITH CHECK (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'comptable'::app_role));
CREATE POLICY "Admin/comptable can update payment_types" ON public.payment_types FOR UPDATE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'comptable'::app_role));
CREATE POLICY "Admin/comptable can delete payment_types" ON public.payment_types FOR DELETE TO authenticated USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'comptable'::app_role));

INSERT INTO public.payment_types (key, label, direction, color) VALUES
  ('recette', 'Recette', 'in', 'bg-green-100 text-green-800'),
  ('depense', 'Dépense', 'out', 'bg-red-100 text-red-800'),
  ('frais', 'Frais scolaires', 'in', 'bg-blue-100 text-blue-800'),
  ('salaire', 'Salaire', 'out', 'bg-yellow-100 text-yellow-800');
