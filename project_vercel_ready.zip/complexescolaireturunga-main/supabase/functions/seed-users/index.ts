import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-seed-secret',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Require a shared secret header to prevent unauthenticated/unauthorized seeding
    const seedSecret = Deno.env.get("SEED_SECRET");
    if (!seedSecret) {
      return new Response(
        JSON.stringify({ error: "Seeding disabled: SEED_SECRET not configured" }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    if (req.headers.get("x-seed-secret") !== seedSecret) {
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Accounts to seed are provided by the caller in the request body
    // Body shape: { users: [{ email, password, role, fullName }, ...] }
    let body: { users?: Array<{ email: string; password: string; role: string; fullName: string }> } = {};
    try {
      body = await req.json();
    } catch {
      // empty body
    }
    const users = Array.isArray(body.users) ? body.users : [];
    if (users.length === 0) {
      return new Response(
        JSON.stringify({ error: "No users provided. Pass { users: [{email,password,role,fullName}] } in the body." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false }
    });

    const results: Array<Record<string, unknown>> = [];

    for (const u of users) {
      if (!u?.email || !u?.password || !u?.role) {
        results.push({ email: u?.email, status: "error", error: "missing fields" });
        continue;
      }
      if (typeof u.password !== "string" || u.password.length < 12) {
        results.push({ email: u.email, status: "error", error: "password must be ≥12 chars" });
        continue;
      }

      const { data: existingUsers } = await supabase.auth.admin.listUsers();
      const existing = existingUsers?.users?.find((eu: any) => eu.email === u.email);

      if (existing) {
        results.push({ email: u.email, status: "already exists" });
        continue;
      }

      const { data: authData, error: authError } = await supabase.auth.admin.createUser({
        email: u.email,
        password: u.password,
        email_confirm: true,
        user_metadata: { full_name: u.fullName ?? "" },
      });

      if (authError) {
        results.push({ email: u.email, status: "error", error: authError.message });
        continue;
      }

      if (authData.user) {
        await supabase.from("user_roles").insert({
          user_id: authData.user.id,
          role: u.role,
        });
        results.push({ email: u.email, status: "created", role: u.role });
      }
    }

    return new Response(JSON.stringify({ success: true, results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: (error as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
