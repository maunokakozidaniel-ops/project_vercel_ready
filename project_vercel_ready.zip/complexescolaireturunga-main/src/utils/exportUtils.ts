import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import "jspdf-autotable";

declare module "jspdf" {
  interface jsPDF {
    autoTable: (options: any) => jsPDF;
  }
}

export const exportToExcel = (data: any[][], headers: string[], fileName: string, sheetName = "Feuille1") => {
  const ws = XLSX.utils.aoa_to_sheet([headers, ...data]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, `${fileName}.xlsx`);
};

export const exportToPDF = (
  data: any[][],
  headers: string[],
  fileName: string,
  title: string,
  subtitle?: string
) => {
  const doc = new jsPDF();
  doc.setFontSize(16);
  doc.text("Complexe Scolaire TURUNGA", doc.internal.pageSize.getWidth() / 2, 15, { align: "center" });
  doc.setFontSize(12);
  doc.text(title, doc.internal.pageSize.getWidth() / 2, 23, { align: "center" });
  if (subtitle) {
    doc.setFontSize(9);
    doc.text(subtitle, doc.internal.pageSize.getWidth() / 2, 29, { align: "center" });
  }

  doc.autoTable({
    head: [headers],
    body: data,
    startY: subtitle ? 34 : 28,
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [30, 64, 175], textColor: 255, fontStyle: "bold" },
    alternateRowStyles: { fillColor: [245, 245, 245] },
  });

  doc.save(`${fileName}.pdf`);
};
