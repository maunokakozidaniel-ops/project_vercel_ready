import CrudModal from "./CrudModal";

interface DeleteConfirmProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  name: string;
}

const DeleteConfirm = ({ open, onClose, onConfirm, name }: DeleteConfirmProps) => (
  <CrudModal open={open} onClose={onClose} title="Confirmer la suppression">
    <p className="text-sm text-muted-foreground mb-6">
      Êtes-vous sûr de vouloir supprimer <span className="font-semibold text-foreground">{name}</span> ? Cette action est irréversible.
    </p>
    <div className="flex justify-end gap-3">
      <button onClick={onClose} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors">
        Annuler
      </button>
      <button onClick={onConfirm} className="rounded-lg bg-destructive px-4 py-2 text-sm font-semibold text-destructive-foreground hover:bg-destructive/90 transition-colors">
        Supprimer
      </button>
    </div>
  </CrudModal>
);

export default DeleteConfirm;
