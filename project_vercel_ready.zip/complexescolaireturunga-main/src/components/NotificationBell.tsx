import { useState, useMemo } from "react";
import { Bell, X, AlertTriangle, Clock } from "lucide-react";
import { useData } from "@/contexts/DataContext";

interface Notification {
  id: string;
  type: "warning" | "info";
  title: string;
  message: string;
}

const NotificationBell = () => {
  const { students, transactions } = useData();
  const [open, setOpen] = useState(false);
  const [dismissed, setDismissed] = useState<string[]>([]);

  const notifications = useMemo(() => {
    const notifs: Notification[] = [];

    // Check students without any payment
    const paidStudentIds = new Set(transactions.filter(t => t.eleve_id).map(t => t.eleve_id!));
    const unpaidStudents = students.filter(s => !paidStudentIds.has(s.id));

    if (unpaidStudents.length > 0) {
      notifs.push({
        id: "unpaid-students",
        type: "warning",
        title: "Élèves sans paiement",
        message: `${unpaidStudents.length} élève(s) n'ont aucun paiement enregistré: ${unpaidStudents.slice(0, 5).map(s => s.nom).join(", ")}${unpaidStudents.length > 5 ? "..." : ""}`,
      });
    }

    // Check for payment types with low amounts (reminders)
    const fraisTransactions = transactions.filter(t => t.type === "frais");
    const totalFrais = fraisTransactions.reduce((a, b) => a + b.montant, 0);
    if (students.length > 0 && fraisTransactions.length > 0) {
      const avgPerStudent = totalFrais / students.length;
      if (avgPerStudent < 50000) {
        notifs.push({
          id: "low-fees",
          type: "info",
          title: "Frais scolaires faibles",
          message: `La moyenne des frais collectés par élève est de ${avgPerStudent.toLocaleString()} FC. Vérifiez les échéances.`,
        });
      }
    }

    // Reminder for classes with many unpaid students
    const classeMap: Record<string, { total: number; unpaid: number }> = {};
    students.forEach(s => {
      if (!classeMap[s.classe]) classeMap[s.classe] = { total: 0, unpaid: 0 };
      classeMap[s.classe].total++;
      if (!paidStudentIds.has(s.id)) classeMap[s.classe].unpaid++;
    });

    Object.entries(classeMap).forEach(([classe, data]) => {
      if (data.unpaid > 0 && data.unpaid / data.total > 0.5) {
        notifs.push({
          id: `class-unpaid-${classe}`,
          type: "warning",
          title: `${classe}: ${data.unpaid}/${data.total} impayés`,
          message: `Plus de la moitié des élèves de ${classe} n'ont pas de paiement enregistré.`,
        });
      }
    });

    return notifs.filter(n => !dismissed.includes(n.id));
  }, [students, transactions, dismissed]);

  const count = notifications.length;

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="relative rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors">
        <Bell className="h-5 w-5" />
        {count > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">{count}</span>
        )}
      </button>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full z-50 mt-2 w-80 rounded-xl border border-border bg-card shadow-lg animate-fade-in">
            <div className="flex items-center justify-between border-b border-border p-3">
              <h3 className="font-semibold text-foreground text-sm">Notifications ({count})</h3>
              <button onClick={() => setOpen(false)} className="text-muted-foreground hover:text-foreground"><X className="h-4 w-4" /></button>
            </div>
            <div className="max-h-80 overflow-y-auto">
              {notifications.length === 0 ? (
                <p className="p-4 text-center text-sm text-muted-foreground">Aucune notification</p>
              ) : (
                notifications.map(n => (
                  <div key={n.id} className="flex gap-3 border-b border-border/50 p-3 last:border-0">
                    <div className={`mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${n.type === "warning" ? "bg-yellow-100" : "bg-blue-100"}`}>
                      {n.type === "warning" ? <AlertTriangle className="h-4 w-4 text-yellow-700" /> : <Clock className="h-4 w-4 text-blue-700" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground">{n.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.message}</p>
                    </div>
                    <button onClick={() => setDismissed(p => [...p, n.id])} className="shrink-0 text-muted-foreground hover:text-foreground"><X className="h-3 w-3" /></button>
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default NotificationBell;
