import { Printer } from "lucide-react";

interface PrintButtonProps {
  title: string;
  contentId: string;
}

const PrintButton = ({ title, contentId }: PrintButtonProps) => {
  const handlePrint = () => {
    const content = document.getElementById(contentId);
    if (!content) return;
    const win = window.open("", "_blank");
    if (!win) return;
    win.document.write(`
      <html><head><title>${title}</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 20px; color: #333; }
        h1 { text-align: center; margin-bottom: 5px; }
        h3 { text-align: center; color: #666; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ccc; padding: 8px 12px; text-align: left; font-size: 13px; }
        th { background: #f5f5f5; font-weight: 600; }
        .no-print { display: none; }
        @media print { .no-print { display: none; } }
      </style></head><body>
      <h1>Complexe Scolaire TURUNGA</h1>
      <h3>${title}</h3>
      ${content.innerHTML}
      </body></html>
    `);
    win.document.close();
    win.print();
  };

  return (
    <button onClick={handlePrint} className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-muted">
      <Printer className="h-4 w-4" />
      Imprimer
    </button>
  );
};

export default PrintButton;
