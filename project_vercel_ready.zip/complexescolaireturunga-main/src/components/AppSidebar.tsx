import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Users, GraduationCap, BookOpen, ClipboardList,
  Settings, LogOut, School, DollarSign, UserCog, Library,
  FileSpreadsheet, CalendarDays, MessageCircle, UserPlus, CalendarRange,
} from "lucide-react";
import { useAuth, UserRole } from "@/contexts/AuthContext";

interface NavItem { to: string; label: string; icon: React.ElementType; roles: UserRole[] }

const navItems: NavItem[] = [
  { to: "/", label: "Administration", icon: LayoutDashboard, roles: ["admin", "secretaire", "comptable"] },
  { to: "/inscription", label: "Inscription", icon: UserPlus, roles: ["admin", "secretaire"] },
  { to: "/eleves", label: "Élèves", icon: Users, roles: ["admin", "secretaire", "comptable"] },
  { to: "/enseignants", label: "Enseignants", icon: GraduationCap, roles: ["admin", "secretaire", "comptable"] },
  { to: "/classes", label: "Classes", icon: BookOpen, roles: ["admin", "secretaire", "comptable"] },
  { to: "/cours", label: "Cours", icon: Library, roles: ["admin", "secretaire"] },
  { to: "/personnel", label: "Personnel", icon: UserCog, roles: ["admin", "comptable"] },
  { to: "/comptabilite", label: "Comptabilité", icon: DollarSign, roles: ["admin", "comptable"] },
  { to: "/notes", label: "Notes", icon: FileSpreadsheet, roles: ["admin", "secretaire"] },
  { to: "/bulletins", label: "Bulletins", icon: ClipboardList, roles: ["admin", "secretaire"] },
  { to: "/emploi-du-temps", label: "Emploi du temps", icon: CalendarDays, roles: ["admin", "secretaire"] },
  { to: "/whatsapp", label: "WhatsApp", icon: MessageCircle, roles: ["admin", "secretaire"] },
  { to: "/annees-scolaires", label: "Années scolaires", icon: CalendarRange, roles: ["admin"] },
  { to: "/parametres", label: "Paramètres", icon: Settings, roles: ["admin"] },
];

const AppSidebar = () => {
  const location = useLocation();
  const { user, logout } = useAuth();
  const visibleItems = navItems.filter((item) => user && item.roles.includes(user.role));

  return (
    <aside className="fixed left-0 top-0 z-40 flex h-screen w-64 flex-col bg-sidebar text-sidebar-foreground shadow-2xl">
      <div className="flex items-center gap-3 px-6 py-5 border-b border-sidebar-border">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sidebar-primary shadow-md">
          <School className="h-6 w-6 text-sidebar-primary-foreground" />
        </div>
        <div>
          <h1 className="text-sm font-bold leading-tight text-sidebar-accent-foreground tracking-wide">Complexe Scolaire</h1>
          <span className="text-xs font-extrabold tracking-[0.2em] text-sidebar-primary">TURUNGA</span>
        </div>
      </div>

      <nav className="flex-1 space-y-0.5 px-3 py-4 overflow-y-auto">
        {visibleItems.map((item) => {
          const isActive = item.to === "/" ? location.pathname === "/" : location.pathname.startsWith(item.to);
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition-all ${
                isActive
                  ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm"
                  : "text-sidebar-foreground/60 hover:bg-sidebar-accent/40 hover:text-sidebar-accent-foreground"
              }`}
            >
              <item.icon className="h-[18px] w-[18px]" />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      <div className="border-t border-sidebar-border px-3 py-4">
        <div className="mb-2 px-3 text-xs text-sidebar-foreground/40">
          Connecté : <span className="font-semibold text-sidebar-foreground/70 capitalize">{user?.fullName}</span>
        </div>
        <button
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-sidebar-foreground/50 transition-all hover:bg-destructive/20 hover:text-destructive"
        >
          <LogOut className="h-4 w-4" />
          Déconnexion
        </button>
      </div>
    </aside>
  );
};

export default AppSidebar;
