import { Outlet, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import AppSidebar from "./AppSidebar";
import NotificationBell from "./NotificationBell";
import SchoolYearSelector from "./SchoolYearSelector";

const AppLayout = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background">
      <AppSidebar />
      <main className="ml-64 min-h-screen">
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-background/80 backdrop-blur-md px-8 py-3">
          <button
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted"
          >
            <ArrowLeft className="h-4 w-4" /> Retour
          </button>
          <div className="flex items-center gap-3">
            <SchoolYearSelector />
            <NotificationBell />
          </div>
        </header>
        <div className="p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default AppLayout;
