import { useSchoolYear } from "@/contexts/SchoolYearContext";
import { Badge } from "@/components/ui/badge";
import { CalendarDays } from "lucide-react";

const SchoolYearSelector = () => {
  const { years, selectedYearId, setSelectedYearId, activeYear } = useSchoolYear();
  if (years.length === 0) return null;
  return (
    <div className="flex items-center gap-2">
      <CalendarDays className="h-4 w-4 text-muted-foreground" />
      <select
        value={selectedYearId || ""}
        onChange={(e) => setSelectedYearId(e.target.value || null)}
        className="rounded-lg border border-border bg-card px-2 py-1.5 text-sm font-medium"
      >
        {years.map((y) => (
          <option key={y.id} value={y.id}>{y.name}</option>
        ))}
      </select>
      {activeYear && selectedYearId === activeYear.id && (
        <Badge className="bg-green-600">Active</Badge>
      )}
    </div>
  );
};

export default SchoolYearSelector;
