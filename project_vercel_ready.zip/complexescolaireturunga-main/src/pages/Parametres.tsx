import { useState, useEffect } from "react";
import { School, Save } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

const Parametres = () => {
  const { settings, updateSettings } = useData();
  const { user } = useAuth();
  const [form, setForm] = useState({
    nom: "", directeur: "", adresse: "", telephone: "", email: "", annee_scolaire: ""
  });

  useEffect(() => {
    if (settings) {
      setForm({
        nom: settings.nom,
        directeur: settings.directeur,
        adresse: settings.adresse,
        telephone: settings.telephone,
        email: settings.email,
        annee_scolaire: settings.annee_scolaire,
      });
    }
  }, [settings]);

  const handleSave = async () => {
    await updateSettings(form);
    toast({ title: "Paramètres sauvegardés", description: "Les informations de l'établissement ont été mises à jour." });
  };

  const inputClass = "w-full rounded-lg border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Paramètres</h1>
        <p className="text-sm text-muted-foreground">Configuration du système</p>
      </div>

      <div className="max-w-2xl space-y-6">
        <div className="rounded-xl border border-border bg-card p-6 animate-fade-in">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary">
              <School className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h2 className="font-bold text-foreground">Informations de l'établissement</h2>
              <p className="text-sm text-muted-foreground">Année scolaire {form.annee_scolaire}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Nom de l'établissement</label>
              <input value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} className={inputClass} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-foreground">Directeur</label>
                <input value={form.directeur} onChange={(e) => setForm({ ...form, directeur: e.target.value })} className={inputClass} placeholder="Nom du directeur" />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-foreground">Année scolaire</label>
                <input value={form.annee_scolaire} onChange={(e) => setForm({ ...form, annee_scolaire: e.target.value })} className={inputClass} placeholder="2025-2026" />
              </div>
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Adresse</label>
              <input value={form.adresse} onChange={(e) => setForm({ ...form, adresse: e.target.value })} className={inputClass} placeholder="Adresse de l'établissement" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-foreground">Téléphone</label>
                <input value={form.telephone} onChange={(e) => setForm({ ...form, telephone: e.target.value })} className={inputClass} placeholder="+243 ..." />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-foreground">Email</label>
                <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputClass} placeholder="email@ecole.cd" />
              </div>
            </div>
          </div>

          <button onClick={handleSave} className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            <Save className="h-4 w-4" />
            Sauvegarder
          </button>
        </div>

        <div className="rounded-xl border border-border bg-card p-6 animate-fade-in">
          <h2 className="font-bold text-foreground mb-4">Utilisateur connecté</h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between border-b border-border pb-3">
              <span className="text-muted-foreground">Nom</span>
              <span className="font-medium text-foreground">{user?.fullName}</span>
            </div>
            <div className="flex justify-between border-b border-border pb-3">
              <span className="text-muted-foreground">Email</span>
              <span className="font-medium text-foreground">{user?.email}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rôle</span>
              <span className="rounded-full bg-primary/15 px-2.5 py-0.5 text-xs font-semibold text-primary capitalize">{user?.role}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Parametres;
