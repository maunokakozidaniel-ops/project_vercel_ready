import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { School, LogIn, Eye, EyeOff } from "lucide-react";

const Login = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email.trim() || !password.trim()) {
      setError("Veuillez remplir tous les champs");
      return;
    }
    setLoading(true);
    const err = await login(email.trim(), password.trim());
    if (err) setError("Identifiants incorrects");
    setLoading(false);
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-[hsl(215,70%,18%)] via-[hsl(215,60%,25%)] to-[hsl(215,70%,18%)] p-4">
      <div className="w-full max-w-md animate-fade-in">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-2xl bg-white/10 backdrop-blur-sm shadow-2xl border border-white/10">
            <School className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Complexe Scolaire</h1>
          <p className="mt-1 text-lg font-bold tracking-[0.15em] text-[hsl(38,85%,52%)]">TURUNGA</p>
          <p className="mt-3 text-sm text-white/60">Connectez-vous pour accéder au système de gestion</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10 p-7 shadow-2xl">
          <div>
            <label className="mb-2 block text-sm font-medium text-white/80">Adresse email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@turunga.cd"
              className="w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-[hsl(38,85%,52%)]/50 focus:border-[hsl(38,85%,52%)]/50 transition-all"
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium text-white/80">Mot de passe</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-xl border border-white/20 bg-white/5 px-4 py-3 pr-11 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-[hsl(38,85%,52%)]/50 focus:border-[hsl(38,85%,52%)]/50 transition-all"
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition-colors">
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {error && (
            <div className="rounded-xl bg-destructive/20 border border-destructive/30 p-3">
              <p className="text-sm font-medium text-red-300">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-[hsl(38,85%,52%)] px-4 py-3 text-sm font-bold text-[hsl(215,70%,10%)] transition-all hover:bg-[hsl(38,85%,58%)] hover:shadow-lg disabled:opacity-50 shadow-md"
          >
            <LogIn className="h-4 w-4" />
            {loading ? "Connexion en cours..." : "Se connecter"}
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-white/30">© 2026 Complexe Scolaire TURUNGA — Tous droits réservés</p>
      </div>
    </div>
  );
};

export default Login;
