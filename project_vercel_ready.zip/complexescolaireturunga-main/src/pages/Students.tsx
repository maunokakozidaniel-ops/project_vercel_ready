import { Search, Plus, Pencil, Trash2, MessageCircle } from "lucide-react";
import { useState } from "react";
import { useData, Student } from "@/contexts/DataContext";
import CrudModal from "@/components/CrudModal";
import DeleteConfirm from "@/components/DeleteConfirm";
import PrintButton from "@/components/PrintButton";

const emptyForm = { nom: "", sexe: "M", classe: "", naissance: "", parent: "", adresse: "", tel_parent: "", matricule: "" };

const Students = () => {
  const { students, addStudent, updateStudent, deleteStudent, classes } = useData();
  const [search, setSearch] = useState("");
  const [filterClasse, setFilterClasse] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [deleting, setDeleting] = useState<Student | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [whatsappMsg, setWhatsappMsg] = useState("");
  const [showWhatsapp, setShowWhatsapp] = useState(false);

  const classesList = classes.length > 0
    ? classes.map(c => c.nom)
    : [...new Set(students.map(s => s.classe))].sort();

  const filtered = students.filter((s) => {
    const q = search.toLowerCase();
    const matchSearch = s.nom.toLowerCase().includes(q) || (s.matricule || "").toLowerCase().includes(q);
    const matchClasse = !filterClasse || s.classe === filterClasse;
    return matchSearch && matchClasse;
  });

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (s: Student) => { setEditing(s); setForm({ nom: s.nom, sexe: s.sexe, classe: s.classe, naissance: s.naissance, parent: s.parent, adresse: s.adresse, tel_parent: s.tel_parent, matricule: s.matricule || "" }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.nom.trim() || !form.classe.trim()) return;
    if (editing) await updateStudent({ ...editing, ...form });
    else await addStudent(form);
    setModalOpen(false);
  };

  const handleDelete = async () => {
    if (deleting) { await deleteStudent(deleting.id); setDeleting(null); }
  };

  const formatPhone = (phone: string) => {
    let p = phone.replace(/\s+/g, "").replace(/[^0-9+]/g, "");
    if (!p.startsWith("+")) p = "+243" + p;
    return p;
  };

  const sendWhatsappToAll = () => {
    if (!whatsappMsg.trim()) return;
    const targets = filtered.filter(s => s.tel_parent);
    targets.forEach((s, i) => {
      setTimeout(() => {
        const phone = formatPhone(s.tel_parent);
        const msg = encodeURIComponent(whatsappMsg.replace("{nom}", s.nom).replace("{classe}", s.classe));
        window.open(`https://wa.me/${phone.replace("+", "")}?text=${msg}`, "_blank");
      }, i * 500);
    });
    setShowWhatsapp(false);
    setWhatsappMsg("");
  };

  const sendWhatsappToOne = (s: Student) => {
    const phone = formatPhone(s.tel_parent);
    window.open(`https://wa.me/${phone.replace("+", "")}`, "_blank");
  };

  const inputClass = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Élèves</h1>
          <p className="text-sm text-muted-foreground">Gestion des élèves inscrits ({students.length})</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowWhatsapp(!showWhatsapp)} className="inline-flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-green-700">
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </button>
          <PrintButton title="Liste des Élèves" contentId="students-table" />
          <button onClick={openAdd} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            <Plus className="h-4 w-4" />
            Nouvel élève
          </button>
        </div>
      </div>

      {showWhatsapp && (
        <div className="rounded-xl border border-green-300 bg-green-50 p-4 dark:bg-green-950/20 dark:border-green-800 animate-fade-in">
          <h3 className="text-sm font-semibold text-foreground mb-2">Envoyer un message WhatsApp aux parents</h3>
          <p className="text-xs text-muted-foreground mb-2">Utilisez {"{nom}"} et {"{classe}"} comme variables. Le message sera envoyé à {filtered.filter(s => s.tel_parent).length} parent(s).</p>
          <textarea value={whatsappMsg} onChange={(e) => setWhatsappMsg(e.target.value)} className={inputClass + " min-h-[80px]"} placeholder="Chers parents de {nom} ({classe}), nous vous informons que..." />
          <div className="flex justify-end gap-2 mt-2">
            <button onClick={() => setShowWhatsapp(false)} className="rounded-lg border border-border px-3 py-1.5 text-sm text-foreground hover:bg-muted">Annuler</button>
            <button onClick={sendWhatsappToAll} className="rounded-lg bg-green-600 px-3 py-1.5 text-sm font-semibold text-white hover:bg-green-700">Envoyer à tous</button>
          </div>
        </div>
      )}

      <div className="flex flex-wrap gap-3">
        <div className="relative max-w-xs flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input type="text" placeholder="Rechercher par nom ou matricule..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-lg border border-input bg-card py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <select value={filterClasse} onChange={(e) => setFilterClasse(e.target.value)} className="rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
          <option value="">Toutes les classes</option>
          {classesList.map((c) => (<option key={c} value={c}>{c}</option>))}
        </select>
      </div>

      <div id="students-table" className="rounded-xl border border-border bg-card animate-fade-in">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50 text-left">
                <th className="px-5 py-3 font-semibold text-muted-foreground">#</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Matricule</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Nom complet</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Sexe</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Classe</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Date naissance</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Parent/Tuteur</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Tél. Parent</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground no-print">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s, i) => (
                <tr key={s.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-5 py-3.5 text-muted-foreground">{i + 1}</td>
                  <td className="px-5 py-3.5 font-mono text-xs font-semibold text-primary">{s.matricule || "—"}</td>
                  <td className="px-5 py-3.5 font-medium text-foreground">{s.nom}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.sexe}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.classe}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.naissance}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.parent}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.tel_parent}</td>
                  <td className="px-5 py-3.5 no-print">
                    <div className="flex gap-1">
                      {s.tel_parent && (
                        <button onClick={() => sendWhatsappToOne(s)} className="rounded-lg p-1.5 text-green-600 hover:bg-green-50 transition-colors" title="WhatsApp"><MessageCircle className="h-4 w-4" /></button>
                      )}
                      <button onClick={() => openEdit(s)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => setDeleting(s)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <CrudModal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Modifier l'élève" : "Nouvel élève"}>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Nom complet</label>
            <input value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} className={inputClass} placeholder="Nom de l'élève" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Sexe</label>
              <select value={form.sexe} onChange={(e) => setForm({ ...form, sexe: e.target.value })} className={inputClass}>
                <option value="M">Masculin</option>
                <option value="F">Féminin</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Classe</label>
              <select value={form.classe} onChange={(e) => setForm({ ...form, classe: e.target.value })} className={inputClass}>
                <option value="">-- Sélectionner --</option>
                {classesList.map((c) => (<option key={c} value={c}>{c}</option>))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Date de naissance</label>
              <input value={form.naissance} onChange={(e) => setForm({ ...form, naissance: e.target.value })} className={inputClass} placeholder="JJ/MM/AAAA" />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Parent/Tuteur</label>
              <input value={form.parent} onChange={(e) => setForm({ ...form, parent: e.target.value })} className={inputClass} placeholder="Nom du parent" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Tél. Parent</label>
              <input value={form.tel_parent} onChange={(e) => setForm({ ...form, tel_parent: e.target.value })} className={inputClass} placeholder="+243 ..." />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Adresse</label>
              <input value={form.adresse} onChange={(e) => setForm({ ...form, adresse: e.target.value })} className={inputClass} placeholder="Adresse de l'élève" />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors">Annuler</button>
            <button onClick={handleSave} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">{editing ? "Modifier" : "Ajouter"}</button>
          </div>
        </div>
      </CrudModal>

      <DeleteConfirm open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete} name={deleting?.nom || ""} />
    </div>
  );
};

export default Students;
