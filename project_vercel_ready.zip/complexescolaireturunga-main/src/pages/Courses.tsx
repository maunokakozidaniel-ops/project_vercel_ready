import { Search, Plus, Pencil, Trash2, BookOpen } from "lucide-react";
import { useState } from "react";
import { useData, Course } from "@/contexts/DataContext";
import CrudModal from "@/components/CrudModal";
import DeleteConfirm from "@/components/DeleteConfirm";
import PrintButton from "@/components/PrintButton";

const emptyForm = { nom: "", coefficient: 2, enseignant: "", classe: "", max_note: 20 };

const Courses = () => {
  const { courses, addCourse, updateCourse, deleteCourse } = useData();
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Course | null>(null);
  const [deleting, setDeleting] = useState<Course | null>(null);
  const [form, setForm] = useState(emptyForm);

  const filtered = courses.filter((c) => c.nom.toLowerCase().includes(search.toLowerCase()));

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (c: Course) => { setEditing(c); setForm({ nom: c.nom, coefficient: c.coefficient, enseignant: c.enseignant, classe: c.classe, max_note: Number(c.max_note) || 20 }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.nom.trim()) return;
    if (editing) await updateCourse({ ...editing, ...form });
    else await addCourse(form);
    setModalOpen(false);
  };

  const handleDelete = async () => { if (deleting) { await deleteCourse(deleting.id); setDeleting(null); } };

  const inputClass = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Cours</h1>
          <p className="text-sm text-muted-foreground">Gestion des matières ({courses.length})</p>
        </div>
        <div className="flex gap-2">
          <PrintButton title="Liste des Cours" contentId="courses-table" />
          <button onClick={openAdd} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            <Plus className="h-4 w-4" />
            Nouveau cours
          </button>
        </div>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input type="text" placeholder="Rechercher un cours..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-lg border border-input bg-card py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
      </div>

      <div id="courses-table" className="rounded-xl border border-border bg-card animate-fade-in">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50 text-left">
                <th className="px-5 py-3 font-semibold text-muted-foreground">#</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Matière</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Coefficient</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Max points</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Enseignant</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Classe</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground no-print">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c, i) => (
                <tr key={c.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-5 py-3.5 text-muted-foreground">{i + 1}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-4 w-4 text-primary" />
                      <span className="font-medium text-foreground">{c.nom}</span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5"><span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-semibold text-primary">{c.coefficient}</span></td>
                  <td className="px-5 py-3.5"><span className="rounded-full bg-amber-500/10 px-2.5 py-0.5 text-xs font-semibold text-amber-700">/{Number(c.max_note) || 20}</span></td>
                  <td className="px-5 py-3.5 text-muted-foreground">{c.enseignant}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{c.classe}</td>
                  <td className="px-5 py-3.5 no-print">
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(c)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => setDeleting(c)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <CrudModal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Modifier le cours" : "Nouveau cours"}>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Nom de la matière</label>
            <input value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} className={inputClass} placeholder="Ex: Mathématiques" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Coefficient</label>
              <input type="number" min={1} max={10} value={form.coefficient} onChange={(e) => setForm({ ...form, coefficient: Number(e.target.value) })} className={inputClass} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Classe</label>
              <input value={form.classe} onChange={(e) => setForm({ ...form, classe: e.target.value })} className={inputClass} placeholder="Ex: 6ème A" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Enseignant</label>
              <input value={form.enseignant} onChange={(e) => setForm({ ...form, enseignant: e.target.value })} className={inputClass} placeholder="Nom de l'enseignant" />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Maximum de points</label>
              <input type="number" min={1} max={200} step={1} value={form.max_note} onChange={(e) => setForm({ ...form, max_note: Number(e.target.value) })} className={inputClass} placeholder="Ex: 20, 40, 100" />
              <p className="mt-1 text-xs text-muted-foreground">Période = {Math.round((Number(form.max_note) || 0) / 2)} • Examen = {Number(form.max_note) || 0}</p>
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors">Annuler</button>
            <button onClick={handleSave} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">{editing ? "Modifier" : "Ajouter"}</button>
          </div>
        </div>
      </CrudModal>

      <DeleteConfirm open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete} name={deleting?.nom || ""} />
    </div>
  );
};

export default Courses;
