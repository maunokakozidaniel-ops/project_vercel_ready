import { useState, useMemo } from "react";
import { Search, Plus, Pencil, Trash2, Calculator, FileText, Download, Printer } from "lucide-react";
import { useData, Grade } from "@/contexts/DataContext";
import { useSchoolYear } from "@/contexts/SchoolYearContext";
import CrudModal from "@/components/CrudModal";
import DeleteConfirm from "@/components/DeleteConfirm";
import PrintButton from "@/components/PrintButton";
import { exportToExcel, exportToPDF } from "@/utils/exportUtils";

const emptyForm = { eleve_id: "", cours_id: "", periode: "1ère Période", note: 0 };

const Notes = () => {
  const { grades, addGrade, updateGrade, deleteGrade, students, courses, updateCourse, teachers, classes, settings } = useData();
  const { activeYear } = useSchoolYear();
  const [search, setSearch] = useState("");
  const [filterClasse, setFilterClasse] = useState("");
  const [filterPeriode, setFilterPeriode] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Grade | null>(null);
  const [deleting, setDeleting] = useState<Grade | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [showFiche, setShowFiche] = useState(false);
  const [ficheClasse, setFicheClasse] = useState("");
  const [ficheCours, setFicheCours] = useState("");

  const periodes = ["1ère Période", "2ème Période", "Examen", "3ème Période", "4ème Période", "Examen S2", "Total Général"];
  const classesList = [...new Set([...students.map((s) => s.classe), ...classes.map(c => c.nom)])].sort();

  // Max note depends on selected course coefficient (use course-specific note max)
  const selectedCourse = courses.find(c => c.id === form.cours_id);
  const formMaxNote = 20; // default, can vary per context

  // For the new note modal: filter students by selected course's class (tolerant match)
  const norm = (s: string) => (s || "").toString().trim().toLowerCase().replace(/\s+/g, " ");
  const formCourseClasse = selectedCourse?.classe || "";
  const formStudents = useMemo(() => {
    if (!formCourseClasse) return students;
    const target = norm(formCourseClasse);
    const matched = students.filter(s => norm(s.classe) === target);
    // Fallback: if no exact match, return all students so the user is never stuck
    return matched.length > 0 ? matched : students;
  }, [formCourseClasse, students]);

  const filtered = grades.filter((g) => {
    const student = students.find((s) => s.id === g.eleve_id);
    const course = courses.find((c) => c.id === g.cours_id);
    const matchSearch = (student?.nom || "").toLowerCase().includes(search.toLowerCase()) || (course?.nom || "").toLowerCase().includes(search.toLowerCase());
    const matchClasse = !filterClasse || student?.classe === filterClasse;
    const matchPeriode = !filterPeriode || g.periode === filterPeriode;
    return matchSearch && matchClasse && matchPeriode;
  });

  const openAdd = () => { setEditing(null); setForm({ ...emptyForm, eleve_id: "", cours_id: courses[0]?.id || "" }); setModalOpen(true); };
  const openEdit = (g: Grade) => { setEditing(g); setForm({ eleve_id: g.eleve_id, cours_id: g.cours_id, periode: g.periode, note: g.note }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.eleve_id || !form.cours_id) return;
    if (editing) await updateGrade({ ...editing, ...form });
    else await addGrade(form);
    setModalOpen(false);
  };

  const handleDelete = async () => { if (deleting) { await deleteGrade(deleting.id); setDeleting(null); } };

  const getStudentAverage = (studentId: string, periode?: string) => {
    const sg = grades.filter((g) => g.eleve_id === studentId && (!periode || g.periode === periode));
    if (sg.length === 0) return null;
    let tw = 0, tc = 0;
    sg.forEach((g) => { const c = courses.find((c) => c.id === g.cours_id); const co = c?.coefficient || 1; tw += g.note * co; tc += co; });
    return tc > 0 ? (tw / tc).toFixed(2) : null;
  };

  // Fiche de cotation: one course + one class
  const ficheCoursObj = useMemo(() => courses.find(c => c.id === ficheCours), [ficheCours, courses]);
  const ficheTeacher = useMemo(() => {
    if (!ficheCoursObj) return "—";
    return ficheCoursObj.enseignant || "—";
  }, [ficheCoursObj]);
  const classInfo = useMemo(() => classes.find(c => c.nom === ficheClasse), [ficheClasse, classes]);

  const ficheCoursesForClass = useMemo(() => {
    return courses.filter(c => c.classe === ficheClasse || !c.classe);
  }, [ficheClasse, courses]);

  const ficheStudents = useMemo(() => {
    if (!ficheClasse) return [];
    return students.filter(s => s.classe === ficheClasse).sort((a, b) => a.nom.localeCompare(b.nom));
  }, [ficheClasse, students]);

  const ficheData = useMemo(() => {
    if (!ficheClasse || !ficheCours) return [];
    return ficheStudents.map(s => {
      const periodNotes: Record<string, number | null> = {};
      periodes.forEach(p => {
        if (p === "Total Général") {
          const allNotes = periodes.filter(pp => pp !== "Total Général").map(pp => periodNotes[pp]).filter((n): n is number => n !== null);
          periodNotes[p] = allNotes.length > 0 ? allNotes.reduce((a, b) => a + b, 0) / allNotes.length : null;
        } else {
          const grade = grades.find(g => g.eleve_id === s.id && g.cours_id === ficheCours && g.periode === p);
          periodNotes[p] = grade?.note ?? null;
        }
      });
      return { student: s, periodNotes };
    });
  }, [ficheClasse, ficheCours, ficheStudents, grades, periodes]);

  const exportFicheExcel = () => {
    if (!ficheClasse || !ficheCours || !ficheCoursObj) return;
    const headers = ["#", "Matricule", "Nom", "Sexe", ...periodes.map(p => p), "Appréciation"];
    const data = ficheData.map((d, i) => [
      i + 1, d.student.matricule || "", d.student.nom, d.student.sexe,
      ...periodes.map(p => d.periodNotes[p] !== null ? Number(d.periodNotes[p]!.toFixed(2)) : ""),
      d.periodNotes["Total Général"] !== null ? getAppreciation(d.periodNotes["Total Général"]!) : "",
    ]);
    exportToExcel(data, headers, `Fiche_${ficheClasse}_${ficheCoursObj.nom}`, `${ficheCoursObj.nom} — ${ficheClasse}`);
  };

  const exportFichePDF = () => {
    if (!ficheClasse || !ficheCours || !ficheCoursObj) return;
    const headers = ["#", "Nom", ...periodes, "Appr."];
    const data = ficheData.map((d, i) => [
      i + 1, d.student.nom,
      ...periodes.map(p => d.periodNotes[p] !== null ? d.periodNotes[p]!.toFixed(1) : "—"),
      d.periodNotes["Total Général"] !== null ? getAppreciationShort(d.periodNotes["Total Général"]!) : "—",
    ]);
    exportToPDF(data, headers, `Fiche_${ficheClasse}_${ficheCoursObj.nom}`, `Fiche de Cotation — ${ficheCoursObj.nom}`, `Classe: ${ficheClasse} | Enseignant: ${ficheTeacher} | Titulaire: ${classInfo?.titulaire || "—"}`);
  };

  // Imprimer la fiche au format papier exact (A4 paysage) — utilisable pour "Enregistrer en PDF"
  const printFichePaper = () => {
    if (!ficheClasse || !ficheCours || !ficheCoursObj) return;
    const node = document.getElementById("fiche-cotation");
    if (!node) return;
    const win = window.open("", "_blank", "width=1200,height=800");
    if (!win) return;
    win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Fiche de Cotation — ${ficheCoursObj.nom} — ${ficheClasse}</title>
      <style>
        @page { size: A4 landscape; margin: 10mm; }
        * { box-sizing: border-box; }
        body { font-family: Arial, Helvetica, sans-serif; color: #000; margin: 0; padding: 0; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th, td { border: 1px solid #000; padding: 3px 4px; }
        thead th { background: #f3f4f6; }
        .title { text-align: center; font-weight: bold; font-size: 18px; text-decoration: underline; letter-spacing: 1px; }
        .school { text-align: center; font-weight: 600; margin-top: 4px; }
        .header { border-bottom: 2px solid #000; padding-bottom: 8px; margin-bottom: 8px; display: flex; align-items: flex-start; gap: 12px; }
        .logo { width: 64px; height: 64px; border: 1px solid #888; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; }
        .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 2px 24px; margin-top: 8px; font-size: 12px; }
        .max td { color: #b91c1c; font-weight: bold; text-align: center; }
        .num, .center { text-align: center; }
        .left { text-align: left; }
        .uppercase { text-transform: uppercase; font-weight: 500; }
        .footer { margin-top: 24px; display: flex; justify-content: space-between; font-size: 12px; }
        .sign { width: 30%; text-align: center; border-top: 1px solid #000; padding-top: 4px; }
      </style>
    </head><body>${node.innerHTML}
      <div class="footer">
        <div class="sign">Le Titulaire</div>
        <div class="sign">Le Préfet des Études</div>
        <div class="sign">Le Directeur</div>
      </div>
      <script>window.onload = () => { window.focus(); window.print(); };</script>
    </body></html>`);
    win.document.close();
  };

  const exportStudentsExcel = () => {
    const list = filterClasse ? students.filter(s => s.classe === filterClasse) : students;
    const headers = ["#", "Matricule", "Nom", "Sexe", "Classe", "Date de naissance", "Parent", "Téléphone"];
    const data = list.map((s, i) => [i + 1, s.matricule || "", s.nom, s.sexe, s.classe, s.naissance, s.parent, s.tel_parent]);
    exportToExcel(data, headers, `Liste_Eleves${filterClasse ? `_${filterClasse}` : ""}`, "Élèves");
  };

  const exportStudentsPDF = () => {
    const list = filterClasse ? students.filter(s => s.classe === filterClasse) : students;
    const headers = ["#", "Matricule", "Nom", "Sexe", "Classe", "Naissance", "Parent", "Tél."];
    const data = list.map((s, i) => [i + 1, s.matricule || "", s.nom, s.sexe, s.classe, s.naissance, s.parent, s.tel_parent]);
    exportToPDF(data, headers, `Liste_Eleves${filterClasse ? `_${filterClasse}` : ""}`, "Liste des Élèves", filterClasse ? `Classe: ${filterClasse}` : undefined);
  };

  const inputClass = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Notes</h1>
          <p className="text-sm text-muted-foreground">Gestion des notes ({grades.length})</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setShowFiche(!showFiche)} className={`inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors ${showFiche ? "bg-accent text-accent-foreground" : "border border-border text-foreground hover:bg-muted"}`}>
            <FileText className="h-4 w-4" /> Fiche de cotation
          </button>
          {showFiche ? (
            <>
              <button onClick={exportFicheExcel} className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2.5 text-sm font-medium text-foreground hover:bg-muted transition-colors"><Download className="h-4 w-4" /> Excel</button>
              <button onClick={exportFichePDF} className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2.5 text-sm font-medium text-foreground hover:bg-muted transition-colors"><Download className="h-4 w-4" /> PDF tableau</button>
              <button onClick={printFichePaper} className="inline-flex items-center gap-2 rounded-lg bg-accent px-3 py-2.5 text-sm font-semibold text-accent-foreground hover:bg-accent/90 transition-colors"><Printer className="h-4 w-4" /> Imprimer / PDF papier</button>
            </>
          ) : (
            <>
              <button onClick={exportStudentsExcel} className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2.5 text-sm font-medium text-foreground hover:bg-muted transition-colors"><Download className="h-4 w-4" /> Liste Excel</button>
              <button onClick={exportStudentsPDF} className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2.5 text-sm font-medium text-foreground hover:bg-muted transition-colors"><Download className="h-4 w-4" /> Liste PDF</button>
              <PrintButton title="Relevé des Notes" contentId="notes-table" />
            </>
          )}
          <button onClick={openAdd} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            <Plus className="h-4 w-4" /> Nouvelle note
          </button>
        </div>
      </div>

      {showFiche && (
        <div className="space-y-4 animate-fade-in">
          <div className="flex flex-wrap gap-3 items-end">
            <div>
              <label className="text-xs text-muted-foreground">Classe</label>
              <select value={ficheClasse} onChange={(e) => { setFicheClasse(e.target.value); setFicheCours(""); }} className="rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring w-full">
                <option value="">-- Classe --</option>
                {classesList.map((c) => (<option key={c} value={c}>{c}</option>))}
              </select>
            </div>
            {ficheClasse && (
              <div>
                <label className="text-xs text-muted-foreground">Cours</label>
                <select value={ficheCours} onChange={(e) => setFicheCours(e.target.value)} className="rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring w-full">
                  <option value="">-- Cours --</option>
                  {ficheCoursesForClass.map(c => (<option key={c.id} value={c.id}>{c.nom} (Coeff. {c.coefficient})</option>))}
                </select>
              </div>
            )}
          </div>

          {ficheClasse && ficheCours && ficheCoursObj && (
            <div id="fiche-cotation" className="rounded-xl border border-border bg-white text-black animate-fade-in print:border-0 print:shadow-none">
              {/* En-tête officiel reproduisant la fiche papier */}
              <div className="px-4 pt-4 pb-3 border-b-2 border-black">
                <div className="flex items-start gap-3">
                  <div className="h-16 w-16 shrink-0 border border-black/40 rounded-full flex items-center justify-center text-[10px] text-center leading-tight">LOGO</div>
                  <div className="flex-1 text-center">
                    <h2 className="text-xl font-bold tracking-wide underline">FICHE DE COTATION</h2>
                    <p className="text-sm font-semibold mt-1">{settings?.nom || "COMPLEXE SCOLAIRE TURUNGA"}</p>
                  </div>
                  <div className="w-16" />
                </div>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1 mt-3 text-[13px]">
                  <div><span className="font-semibold">ANNÉE SCOLAIRE :</span> {activeYear?.name || "—"}</div>
                  <div><span className="font-semibold">BRANCHE :</span> {ficheCoursObj.nom}</div>
                  <div><span className="font-semibold">CLASSE :</span> {ficheClasse}</div>
                  <div><span className="font-semibold">TITULAIRE DE LA CLASSE :</span> {classInfo?.titulaire || "—"}</div>
                  <div></div>
                  <div><span className="font-semibold">TITULAIRE DU COURS :</span> {ficheTeacher}</div>
                </div>
              </div>

              {/* Tableau à la manière papier : 2 semestres avec sous-colonnes */}
              <div className="overflow-x-auto p-3">
                <table className="w-full border-collapse text-[12px]">
                  <thead>
                    <tr>
                      <th rowSpan={2} className="border border-black px-2 py-1 w-8 align-middle">N°</th>
                      <th rowSpan={2} className="border border-black px-2 py-1 text-left align-middle">NOMS ET POST-NOMS</th>
                      <th colSpan={4} className="border border-black px-2 py-1 text-center">PREMIER SEMESTRE</th>
                      <th colSpan={4} className="border border-black px-2 py-1 text-center">DEUXIÈME SEMESTRE</th>
                      <th rowSpan={2} className="border border-black px-2 py-1 text-center align-middle w-12">G.T</th>
                    </tr>
                    <tr>
                      <th className="border border-black px-1 py-1 text-center w-10">1ère P</th>
                      <th className="border border-black px-1 py-1 text-center w-10">2ème P</th>
                      <th className="border border-black px-1 py-1 text-center w-12">EXAM</th>
                      <th className="border border-black px-1 py-1 text-center w-12">TOTAL</th>
                      <th className="border border-black px-1 py-1 text-center w-10">3ème P</th>
                      <th className="border border-black px-1 py-1 text-center w-10">4ème P</th>
                      <th className="border border-black px-1 py-1 text-center w-12">EXAM</th>
                      <th className="border border-black px-1 py-1 text-center w-12">TOTAL</th>
                    </tr>
                    {/* Ligne MAX */}
                    <tr className="bg-muted/40">
                      <td className="border border-black px-2 py-1"></td>
                      <td className="border border-black px-2 py-1 text-right font-semibold italic">MAX</td>
                      {(() => {
                        const m = ficheCoursObj.max_note || 20;
                        const half = Math.round(m / 2);
                        const exam = m;
                        const tot = half * 2 + exam;
                        return (
                          <>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{half}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{half}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{exam}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{tot}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{half}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{half}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{exam}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{tot}</td>
                            <td className="border border-black px-1 py-1 text-center font-bold text-red-600">{tot * 2}</td>
                          </>
                        );
                      })()}
                    </tr>
                  </thead>
                  <tbody>
                    {ficheData.map((d, i) => {
                      const p1 = d.periodNotes["1ère Période"];
                      const p2 = d.periodNotes["2ème Période"];
                      const p3 = d.periodNotes["3ème Période"];
                      const p4 = d.periodNotes["4ème Période"];
                      const ex = d.periodNotes["Examen"];
                      const cell = (n: number | null | undefined) =>
                        n !== null && n !== undefined ? (typeof n === "number" ? n.toFixed(0) : String(n)) : "";
                      const sum = (...arr: (number | null | undefined)[]) => {
                        const vals = arr.filter((n): n is number => typeof n === "number");
                        return vals.length === arr.length && vals.length > 0 ? vals.reduce((a, b) => a + b, 0) : null;
                      };
                      const tot1 = sum(p1, p2, ex);
                      const tot2 = sum(p3, p4, ex);
                      const gt = tot1 !== null && tot2 !== null ? tot1 + tot2 : null;
                      return (
                        <tr key={d.student.id} className="hover:bg-muted/20">
                          <td className="border border-black px-2 py-1 text-center">{String(i + 1).padStart(2, "0")}.</td>
                          <td className="border border-black px-2 py-1 uppercase font-medium">{d.student.nom}</td>
                          <td className="border border-black px-1 py-1 text-center">{cell(p1)}</td>
                          <td className="border border-black px-1 py-1 text-center">{cell(p2)}</td>
                          <td className="border border-black px-1 py-1 text-center">{cell(ex)}</td>
                          <td className="border border-black px-1 py-1 text-center font-semibold">{cell(tot1)}</td>
                          <td className="border border-black px-1 py-1 text-center">{cell(p3)}</td>
                          <td className="border border-black px-1 py-1 text-center">{cell(p4)}</td>
                          <td className="border border-black px-1 py-1 text-center"></td>
                          <td className="border border-black px-1 py-1 text-center font-semibold">{cell(tot2)}</td>
                          <td className="border border-black px-1 py-1 text-center font-bold">{cell(gt)}</td>
                        </tr>
                      );
                    })}
                    {ficheData.length === 0 && (
                      <tr><td colSpan={11} className="border border-black px-3 py-6 text-center text-muted-foreground">Aucun élève dans cette classe</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {!showFiche && (
        <>
          <div className="flex flex-wrap gap-3">
            <div className="relative max-w-xs flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input type="text" placeholder="Rechercher par élève ou cours..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-lg border border-input bg-card py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>
            <select value={filterClasse} onChange={(e) => setFilterClasse(e.target.value)} className="rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="">Toutes les classes</option>
              {classesList.map((c) => (<option key={c} value={c}>{c}</option>))}
            </select>
            <select value={filterPeriode} onChange={(e) => setFilterPeriode(e.target.value)} className="rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
              <option value="">Toutes les périodes</option>
              {periodes.map((p) => (<option key={p} value={p}>{p}</option>))}
            </select>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10"><Calculator className="h-5 w-5 text-primary" /></div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{grades.length}</p>
                  <p className="text-xs text-muted-foreground">Notes enregistrées</p>
                </div>
              </div>
            </div>
            <div className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/20"><Calculator className="h-5 w-5 text-accent-foreground" /></div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{grades.length > 0 ? (grades.reduce((a, g) => a + g.note, 0) / grades.length).toFixed(1) : "—"}</p>
                  <p className="text-xs text-muted-foreground">Moyenne générale</p>
                </div>
              </div>
            </div>
            <div className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100"><Calculator className="h-5 w-5 text-green-700" /></div>
                <div>
                  <p className="text-2xl font-bold text-foreground">{grades.filter((g) => g.note >= 10).length}</p>
                  <p className="text-xs text-muted-foreground">Notes ≥ 10/20</p>
                </div>
              </div>
            </div>
          </div>

          <div id="notes-table" className="rounded-xl border border-border bg-card animate-fade-in">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50 text-left">
                    <th className="px-5 py-3 font-semibold text-muted-foreground">#</th>
                    <th className="px-5 py-3 font-semibold text-muted-foreground">Élève</th>
                    <th className="px-5 py-3 font-semibold text-muted-foreground">Classe</th>
                    <th className="px-5 py-3 font-semibold text-muted-foreground">Cours</th>
                    <th className="px-5 py-3 font-semibold text-muted-foreground">Période</th>
                    <th className="px-5 py-3 font-semibold text-muted-foreground">Note /20</th>
                    <th className="px-5 py-3 font-semibold text-muted-foreground">Moy.</th>
                    <th className="px-5 py-3 font-semibold text-muted-foreground no-print">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((g, i) => {
                    const student = students.find((s) => s.id === g.eleve_id);
                    const course = courses.find((c) => c.id === g.cours_id);
                    const avg = getStudentAverage(g.eleve_id, g.periode);
                    return (
                      <tr key={g.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors">
                        <td className="px-5 py-3.5 text-muted-foreground">{i + 1}</td>
                        <td className="px-5 py-3.5 font-medium text-foreground">{student?.nom || "—"}</td>
                        <td className="px-5 py-3.5 text-muted-foreground">{student?.classe || "—"}</td>
                        <td className="px-5 py-3.5 text-muted-foreground">{course?.nom || "—"}</td>
                        <td className="px-5 py-3.5 text-muted-foreground">{g.periode}</td>
                        <td className="px-5 py-3.5">
                          <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold ${g.note >= 14 ? "bg-green-100 text-green-800" : g.note >= 10 ? "bg-yellow-100 text-yellow-800" : "bg-red-100 text-red-800"}`}>
                            {g.note}/20
                          </span>
                        </td>
                        <td className="px-5 py-3.5 text-muted-foreground font-medium">{avg || "—"}</td>
                        <td className="px-5 py-3.5 no-print">
                          <div className="flex gap-1">
                            <button onClick={() => openEdit(g)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"><Pencil className="h-4 w-4" /></button>
                            <button onClick={() => setDeleting(g)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filtered.length === 0 && (
                    <tr><td colSpan={8} className="px-5 py-10 text-center text-muted-foreground">Aucune note trouvée</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      <CrudModal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Modifier la note" : "Nouvelle note"}>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Cours</label>
            <select value={form.cours_id} onChange={(e) => setForm({ ...form, cours_id: e.target.value, eleve_id: "" })} className={inputClass}>
              <option value="">-- Sélectionner --</option>
              {courses.map((c) => (<option key={c.id} value={c.id}>{c.nom} — {c.classe} (Coeff. {c.coefficient})</option>))}
            </select>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Élève {formCourseClasse ? `(${formCourseClasse})` : ""}</label>
            <select value={form.eleve_id} onChange={(e) => setForm({ ...form, eleve_id: e.target.value })} className={inputClass}>
              <option value="">-- Sélectionner --</option>
              {formStudents.map((s) => (<option key={s.id} value={s.id}>{s.nom} ({s.classe})</option>))}
            </select>
          </div>
          {selectedCourse && (
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">
                Maximum du cours
                <span className="ml-1 text-xs text-muted-foreground">(barème total — examen)</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  min={1}
                  max={200}
                  step={1}
                  defaultValue={Number(selectedCourse.max_note) || 20}
                  key={selectedCourse.id}
                  onBlur={async (e) => {
                    const v = Math.max(1, Number(e.target.value) || 20);
                    if (v !== Number(selectedCourse.max_note)) {
                      await updateCourse({ ...selectedCourse, max_note: v });
                    }
                  }}
                  className={inputClass}
                />
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                Ce maximum s'applique au cours « {selectedCourse.nom} ». Périodes = max/2, Examen = max.
              </p>
            </div>
          )}
          {selectedCourse && (() => {
            const m = Number(selectedCourse.max_note) || 20;
            const half = Math.round(m / 2);
            return (
              <div className="rounded-lg border border-border bg-muted/40 p-3">
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Barème du cours</p>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-md bg-background p-2 border border-border">
                    <p className="text-[10px] text-muted-foreground">Période</p>
                    <p className="text-lg font-bold text-foreground">/{half}</p>
                  </div>
                  <div className="rounded-md bg-background p-2 border border-border">
                    <p className="text-[10px] text-muted-foreground">Examen</p>
                    <p className="text-lg font-bold text-foreground">/{m}</p>
                  </div>
                  <div className="rounded-md bg-background p-2 border border-border">
                    <p className="text-[10px] text-muted-foreground">Total semestre</p>
                    <p className="text-lg font-bold text-foreground">/{half * 2 + m}</p>
                  </div>
                </div>
              </div>
            );
          })()}
          {(() => {
            const courseMax = Number(selectedCourse?.max_note) || 20;
            const isExam = /exam/i.test(form.periode || "");
            const periodMax = isExam ? courseMax : Math.round(courseMax / 2);
            return (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1 block text-sm font-medium text-foreground">Période</label>
                  <select
                    value={form.periode}
                    onChange={(e) => {
                      const newPeriod = e.target.value;
                      const newIsExam = /exam/i.test(newPeriod);
                      const newMax = newIsExam ? courseMax : Math.round(courseMax / 2);
                      setForm({ ...form, periode: newPeriod, note: Math.min(newMax, Number(form.note) || 0) });
                    }}
                    className={inputClass}
                  >
                    {periodes.filter(p => p !== "Total Général").map((p) => (<option key={p} value={p}>{p}</option>))}
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-foreground">
                    Note /{periodMax}
                    {selectedCourse ? (
                      <span className="ml-1 text-xs text-muted-foreground">
                        ({isExam ? "examen" : "période"} — max défini par le cours)
                      </span>
                    ) : null}
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={periodMax}
                    step={0.5}
                    value={form.note}
                    onChange={(e) => {
                      setForm({ ...form, note: Math.min(periodMax, Math.max(0, Number(e.target.value))) });
                    }}
                    className={inputClass}
                    disabled={!form.cours_id}
                  />
                </div>
              </div>
            );
          })()}
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors">Annuler</button>
            <button onClick={handleSave} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">{editing ? "Modifier" : "Ajouter"}</button>
          </div>
        </div>
      </CrudModal>

      <DeleteConfirm open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete} name={`note de ${students.find((s) => s.id === deleting?.eleve_id)?.nom || ""}`} />
    </div>
  );
};

function getAppreciation(avg: number): string {
  if (avg >= 16) return "Excellent";
  if (avg >= 14) return "Très Bien";
  if (avg >= 12) return "Bien";
  if (avg >= 10) return "Assez Bien";
  if (avg >= 8) return "Médiocre";
  return "Insuffisant";
}

function getAppreciationShort(avg: number): string {
  if (avg >= 16) return "Exc.";
  if (avg >= 14) return "TB";
  if (avg >= 12) return "B";
  if (avg >= 10) return "AB";
  if (avg >= 8) return "Méd.";
  return "Ins.";
}

function getFicheStats(ficheData: { periodNotes: Record<string, number | null> }[]) {
  const totals = ficheData.map(d => d.periodNotes["Total Général"]).filter((n): n is number => n !== null);
  if (totals.length === 0) return null;
  const avg = totals.reduce((a, b) => a + b, 0) / totals.length;
  return {
    avg: avg.toFixed(2),
    max: Math.max(...totals).toFixed(2),
    min: Math.min(...totals).toFixed(2),
    passed: totals.filter(n => n >= 10).length,
    total: totals.length,
  };
}

export default Notes;
