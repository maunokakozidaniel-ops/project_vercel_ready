import { useState } from "react";
import { MessageCircle, Send, Users } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import PrintButton from "@/components/PrintButton";

const WhatsApp = () => {
  const { students, classes } = useData();
  const [filterClasse, setFilterClasse] = useState("");
  const [message, setMessage] = useState("");

  const classesList = classes.length > 0 ? classes.map(c => c.nom) : [...new Set(students.map(s => s.classe))].sort();

  const filtered = filterClasse ? students.filter(s => s.classe === filterClasse) : students;
  const parentsWithPhone = filtered.filter(s => s.tel_parent?.trim());

  const formatPhone = (phone: string) => {
    let p = phone.replace(/\s+/g, "").replace(/[^0-9+]/g, "");
    if (!p.startsWith("+")) p = "+243" + p;
    return p;
  };

  const sendIndividual = (student: typeof students[0]) => {
    if (!student.tel_parent) return;
    const msg = message.replace("{nom}", student.nom).replace("{classe}", student.classe);
    window.open(`https://wa.me/${formatPhone(student.tel_parent)}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  const sendToAll = () => {
    if (!message.trim()) return;
    parentsWithPhone.forEach((s, i) => {
      setTimeout(() => sendIndividual(s), i * 500);
    });
  };

  const inputClass = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Communication WhatsApp</h1>
          <p className="text-sm text-muted-foreground">Envoyer des messages aux parents via WhatsApp</p>
        </div>
        <PrintButton title="Liste des contacts" contentId="whatsapp-contacts" />
      </div>

      <div className="rounded-xl border border-border bg-card p-6 space-y-4 animate-fade-in">
        <h3 className="font-semibold text-foreground flex items-center gap-2"><MessageCircle className="h-5 w-5 text-green-600" /> Composer un message</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Filtrer par classe</label>
            <select value={filterClasse} onChange={e => setFilterClasse(e.target.value)} className={inputClass}>
              <option value="">Toutes les classes</option>
              {classesList.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div className="flex items-end">
            <p className="text-sm text-muted-foreground"><Users className="inline h-4 w-4 mr-1" />{parentsWithPhone.length} parents avec numéro</p>
          </div>
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-foreground">Message (variables: {"{nom}"}, {"{classe}"})</label>
          <textarea value={message} onChange={e => setMessage(e.target.value)} rows={4} className={inputClass} placeholder="Cher parent de {nom}, classe {classe}..." />
        </div>
        <button onClick={sendToAll} disabled={!message.trim() || parentsWithPhone.length === 0} className="inline-flex items-center gap-2 rounded-lg bg-green-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-green-700 transition-colors disabled:opacity-50">
          <Send className="h-4 w-4" /> Envoyer à tous ({parentsWithPhone.length})
        </button>
      </div>

      <div id="whatsapp-contacts" className="rounded-xl border border-border bg-card animate-fade-in">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50 text-left">
                <th className="px-5 py-3 font-semibold text-muted-foreground">#</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Élève</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Classe</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Parent</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground">Téléphone</th>
                <th className="px-5 py-3 font-semibold text-muted-foreground no-print">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s, i) => (
                <tr key={s.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-5 py-3.5 text-muted-foreground">{i + 1}</td>
                  <td className="px-5 py-3.5 font-medium text-foreground">{s.nom}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.classe}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.parent || "—"}</td>
                  <td className="px-5 py-3.5 text-muted-foreground">{s.tel_parent || "—"}</td>
                  <td className="px-5 py-3.5 no-print">
                    {s.tel_parent ? (
                      <button onClick={() => sendIndividual(s)} className="inline-flex items-center gap-1 rounded-lg bg-green-100 px-3 py-1 text-xs font-medium text-green-800 hover:bg-green-200 transition-colors">
                        <MessageCircle className="h-3 w-3" /> Envoyer
                      </button>
                    ) : <span className="text-xs text-muted-foreground">Pas de numéro</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WhatsApp;
