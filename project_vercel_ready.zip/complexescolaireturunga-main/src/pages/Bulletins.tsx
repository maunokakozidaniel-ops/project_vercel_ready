import { Fragment, useState, useMemo } from "react";
import { FileText, Printer } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { useSchoolYear } from "@/contexts/SchoolYearContext";

const PERIODES_S1 = ["1ère Période", "2ème Période", "Examen S1"];
const PERIODES_S2 = ["3ème Période", "4ème Période", "Examen S2"];

// Map UI semester period -> period name stored in DB
// We support both new ("Examen S1") and existing ("Examen") keys.
const matchPeriod = (storedPeriode: string, target: string) => {
  if (storedPeriode === target) return true;
  if (target === "Examen S1" && storedPeriode === "Examen") return true;
  return false;
};

const Bulletins = () => {
  const { students, courses, grades, settings, classes } = useData();
  const { activeYear } = useSchoolYear();
  const [selectedClasse, setSelectedClasse] = useState("");
  const [selectedStudent, setSelectedStudent] = useState("");

  const classesList = [...new Set(students.map((s) => s.classe))].sort();
  const filteredStudents = students.filter((s) => !selectedClasse || s.classe === selectedClasse);
  const student = students.find((s) => s.id === selectedStudent);

  // Branches = courses for student's class
  const branches = useMemo(() => {
    if (!student) return [];
    return courses
      .filter((c) => c.classe === student.classe || !c.classe)
      .sort((a, b) => a.nom.localeCompare(b.nom));
  }, [student, courses]);

  type Row = {
    cours: string;
    max_note: number;
    s1: { p1: number | null; p2: number | null; exam: number | null; tot: number | null };
    s2: { p3: number | null; p4: number | null; exam: number | null; tot: number | null };
    gt: number | null;
  };

  const rows: Row[] = useMemo(() => {
    if (!student) return [];
    return branches.map((c) => {
      const findNote = (periode: string) => {
        const g = grades.find(
          (gg) => gg.eleve_id === student.id && gg.cours_id === c.id && matchPeriod(gg.periode, periode),
        );
        return g ? Number(g.note) : null;
      };
      const p1 = findNote("1ère Période");
      const p2 = findNote("2ème Période");
      const eS1 = findNote("Examen S1");
      const p3 = findNote("3ème Période");
      const p4 = findNote("4ème Période");
      const eS2 = findNote("Examen S2");
      const sum = (...vals: (number | null)[]) => {
        const arr = vals.filter((v): v is number => v !== null);
        return arr.length ? arr.reduce((a, b) => a + b, 0) : null;
      };
      const tot1 = sum(p1, p2, eS1);
      const tot2 = sum(p3, p4, eS2);
      const gt = sum(tot1, tot2);
      return {
        cours: c.nom,
        max_note: Number(c.max_note) || 20,
        s1: { p1, p2, exam: eS1, tot: tot1 },
        s2: { p3, p4, exam: eS2, tot: tot2 },
        gt,
      };
    });
  }, [student, branches, grades]);

  // Maxima totals
  const maxima = useMemo(() => {
    const sumMax = (sub: "period" | "exam" | "tot") => {
      return rows.reduce((acc, r) => {
        if (sub === "period") return acc + Math.round(r.max_note / 2);
        if (sub === "exam") return acc + r.max_note;
        return acc + Math.round(r.max_note / 2) * 2 + r.max_note; // tot per row
      }, 0);
    };
    const maxS1Tot = sumMax("tot");
    const maxGT = maxS1Tot * 2;
    return {
      perPeriod: sumMax("period"),
      perExam: sumMax("exam"),
      perSemestre: maxS1Tot,
      gt: maxGT,
    };
  }, [rows]);

  // Totals per student
  const totals = useMemo(() => {
    const sumCol = (fn: (r: Row) => number | null) =>
      rows.reduce((acc, r) => acc + (fn(r) ?? 0), 0);
    const tS1 = sumCol((r) => r.s1.tot);
    const tS2 = sumCol((r) => r.s2.tot);
    const gt = tS1 + tS2;
    const pct = maxima.gt > 0 ? (gt / maxima.gt) * 100 : 0;
    return {
      p1: sumCol((r) => r.s1.p1), p2: sumCol((r) => r.s1.p2), eS1: sumCol((r) => r.s1.exam), tS1,
      p3: sumCol((r) => r.s2.p3), p4: sumCol((r) => r.s2.p4), eS2: sumCol((r) => r.s2.exam), tS2,
      gt, pct,
    };
  }, [rows, maxima]);

  // Class ranking (by GT)
  const classGT = useMemo(() => {
    if (!student) return [];
    const others = students.filter((s) => s.classe === student.classe);
    return others
      .map((s) => {
        let gt = 0;
        branches.forEach((c) => {
          grades
            .filter((g) => g.eleve_id === s.id && g.cours_id === c.id)
            .forEach((g) => (gt += Number(g.note)));
        });
        return { id: s.id, gt };
      })
      .sort((a, b) => b.gt - a.gt);
  }, [student, students, branches, grades]);

  const rank = classGT.findIndex((x) => x.id === selectedStudent) + 1;

  const fmt = (v: number | null | undefined) =>
    v === null || v === undefined ? "" : Number.isInteger(v) ? String(v).padStart(2, "0") : v.toFixed(1);

  const printBulletin = () => {
    const node = document.getElementById("bulletin-rdc");
    if (!node) return;
    const win = window.open("", "_blank", "width=1200,height=800");
    if (!win) return;
    win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Bulletin — ${student?.nom || ""}</title>
      <style>
        @page { size: A4 portrait; margin: 8mm; }
        * { box-sizing: border-box; }
        body { font-family: 'Times New Roman', serif; color: #000; margin: 0; padding: 0; }
        .head { text-align: center; line-height: 1.2; }
        .head h1 { font-size: 13px; margin: 0; font-weight: bold; }
        .head h2 { font-size: 12px; margin: 0; font-weight: normal; }
        .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 2px 16px; font-size: 11px; margin: 6px 0; }
        .meta b { font-weight: bold; }
        .title { text-align: center; font-weight: bold; font-size: 13px; text-decoration: underline; margin: 6px 0; letter-spacing: 1px; }
        table { width: 100%; border-collapse: collapse; font-size: 10px; }
        th, td { border: 1px solid #000; padding: 2px 3px; text-align: center; }
        th { background: #efefef; font-weight: bold; }
        .left { text-align: left; padding-left: 4px; }
        .max { color: #b91c1c; font-weight: bold; }
        .total-row td { font-weight: bold; background: #f5f5f5; }
        .footer { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-top: 18px; font-size: 11px; text-align: center; }
        .sign { margin-top: 32px; border-top: 1px solid #000; padding-top: 3px; }
      </style>
    </head><body>${node.innerHTML}
      <script>window.onload=()=>{window.focus();window.print();};</script>
    </body></html>`);
    win.document.close();
  };

  // Extract grade level (e.g. "1ère ANNÉE HUMANITÉS") from class name
  const classLevel = student?.classe || "";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Bulletins Scolaires</h1>
          <p className="text-sm text-muted-foreground">Format officiel RDC — Ministère de l'EPST</p>
        </div>
        {selectedStudent && rows.length > 0 && (
          <button onClick={printBulletin} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90">
            <Printer className="h-4 w-4" /> Imprimer / PDF
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-sm font-medium text-foreground">Classe</label>
          <select value={selectedClasse} onChange={(e) => { setSelectedClasse(e.target.value); setSelectedStudent(""); }}
            className="w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm">
            <option value="">Toutes les classes</option>
            {classesList.map((c) => (<option key={c} value={c}>{c}</option>))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-sm font-medium text-foreground">Élève</label>
          <select value={selectedStudent} onChange={(e) => setSelectedStudent(e.target.value)}
            className="w-full rounded-lg border border-input bg-card px-3 py-2.5 text-sm">
            <option value="">-- Sélectionner --</option>
            {filteredStudents.map((s) => (<option key={s.id} value={s.id}>{s.nom} ({s.classe})</option>))}
          </select>
        </div>
      </div>

      {!selectedStudent ? (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card py-16">
          <FileText className="h-12 w-12 text-muted-foreground/40" />
          <h3 className="mt-4 text-lg font-semibold">Sélectionnez un élève</h3>
        </div>
      ) : (
        <div id="bulletin-rdc" className="rounded-xl border border-border bg-white text-black p-4 overflow-x-auto">
          <div className="head">
            <h1>RÉPUBLIQUE DÉMOCRATIQUE DU CONGO</h1>
            <h1>MINISTÈRE DE L'ÉDUCATION NATIONALE</h1>
            <h1>ET NOUVELLE CITOYENNETÉ</h1>
          </div>

          <div className="meta">
            <div><b>PROVINCE ÉDUCATIONNELLE :</b> {settings?.adresse || "............................"}</div>
            <div><b>ÉLÈVE :</b> {student?.nom}</div>
            <div><b>VILLE :</b> ...........................</div>
            <div><b>NÉ(E) À :</b> {student?.naissance || "..........."}</div>
            <div><b>COMMUNE / TER. :</b> ...........................</div>
            <div><b>CLASSE :</b> {student?.classe}</div>
            <div><b>ÉCOLE :</b> {settings?.nom || "Complexe Scolaire TURUNGA"}</div>
            <div><b>N° PERM. :</b> {student?.matricule || ""}</div>
            <div><b>CODE :</b> ___________</div>
            <div><b>SEXE :</b> {student?.sexe}</div>
          </div>

          <p className="title">BULLETIN DE LA {classLevel.toUpperCase()} — ANNÉE SCOLAIRE {activeYear?.name || settings?.annee_scolaire || "2025-2026"}</p>

          <table>
            <thead>
              <tr>
                <th rowSpan={2} className="left">BRANCHES</th>
                <th colSpan={4}>PREMIER SEMESTRE</th>
                <th colSpan={4}>SECOND SEMESTRE</th>
                <th rowSpan={2}>T.G.</th>
              </tr>
              <tr>
                <th>1ère P.</th><th>2ème P.</th><th>EXAM.</th><th>TOT.</th>
                <th>3ème P.</th><th>4ème P.</th><th>EXAM.</th><th>TOT.</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const half = Math.round(r.max_note / 2);
                const exam = r.max_note;
                const totSem = half * 2 + exam;
                const gtMax = totSem * 2;
                return (
                  <Fragment key={i}>
                    <tr>
                      <td className="left max">MAXIMA</td>
                      <td className="max">{half}</td>
                      <td className="max">{half}</td>
                      <td className="max">{exam}</td>
                      <td className="max">{totSem}</td>
                      <td className="max">{half}</td>
                      <td className="max">{half}</td>
                      <td className="max">{exam}</td>
                      <td className="max">{totSem}</td>
                      <td className="max">{gtMax}</td>
                    </tr>
                    <tr>
                      <td className="left">{r.cours}</td>
                      <td>{fmt(r.s1.p1)}</td>
                      <td>{fmt(r.s1.p2)}</td>
                      <td>{fmt(r.s1.exam)}</td>
                      <td><b>{fmt(r.s1.tot)}</b></td>
                      <td>{fmt(r.s2.p3)}</td>
                      <td>{fmt(r.s2.p4)}</td>
                      <td>{fmt(r.s2.exam)}</td>
                      <td><b>{fmt(r.s2.tot)}</b></td>
                      <td><b>{fmt(r.gt)}</b></td>
                    </tr>
                  </Fragment>
                );
              })}
              <tr className="total-row">
                <td className="left">MAXIMA GÉNÉRAUX</td>
                <td>{maxima.perPeriod}</td><td>{maxima.perPeriod}</td><td>{maxima.perExam}</td><td>{maxima.perSemestre}</td>
                <td>{maxima.perPeriod}</td><td>{maxima.perPeriod}</td><td>{maxima.perExam}</td><td>{maxima.perSemestre}</td>
                <td>{maxima.gt}</td>
              </tr>
              <tr className="total-row">
                <td className="left">TOTAUX</td>
                <td>{fmt(totals.p1)}</td><td>{fmt(totals.p2)}</td><td>{fmt(totals.eS1)}</td><td>{fmt(totals.tS1)}</td>
                <td>{fmt(totals.p3)}</td><td>{fmt(totals.p4)}</td><td>{fmt(totals.eS2)}</td><td>{fmt(totals.tS2)}</td>
                <td>{fmt(totals.gt)}</td>
              </tr>
              <tr className="total-row">
                <td className="left">POURCENTAGE</td>
                <td colSpan={4}>{maxima.perSemestre > 0 ? ((totals.tS1 / maxima.perSemestre) * 100).toFixed(1) : "0"} %</td>
                <td colSpan={4}>{maxima.perSemestre > 0 ? ((totals.tS2 / maxima.perSemestre) * 100).toFixed(1) : "0"} %</td>
                <td>{totals.pct.toFixed(1)} %</td>
              </tr>
              <tr>
                <td className="left">PLACE / NBRE D'ÉLÈVES</td>
                <td colSpan={9}>{rank} / {classGT.length}</td>
              </tr>
              <tr>
                <td className="left">APPLICATION</td><td colSpan={9}></td>
              </tr>
              <tr>
                <td className="left">CONDUITE</td><td colSpan={9}></td>
              </tr>
            </tbody>
          </table>

          <div className="footer">
            <div>
              <p>Signature du responsable</p>
              <div className="sign">&nbsp;</div>
            </div>
            <div>
              <p>Chef d'Établissement</p>
              <div className="sign">{settings?.directeur || "Nom et Signature"}</div>
            </div>
          </div>

          <p style={{ marginTop: 8, fontSize: 10, fontStyle: "italic", textAlign: "center" }}>
            Décision : <b>{totals.pct >= 50 ? "L'élève passe dans la classe supérieure" : "L'élève double la classe"}</b>
          </p>
        </div>
      )}
    </div>
  );
};

export default Bulletins;
