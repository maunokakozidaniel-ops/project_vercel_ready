import { useState, useEffect, useCallback, useMemo } from "react";
import { Search, Plus, Pencil, Trash2, TrendingUp, TrendingDown, Wallet, Settings, Printer, History, MessageSquare } from "lucide-react";
import { useData, Transaction } from "@/contexts/DataContext";
import { supabase } from "@/integrations/supabase/client";
import CrudModal from "@/components/CrudModal";
import DeleteConfirm from "@/components/DeleteConfirm";
import PrintButton from "@/components/PrintButton";

type PaymentType = { id: string; key: string; label: string; direction: "in" | "out"; color: string };

const Comptabilite = () => {
  const { transactions, addTransaction, updateTransaction, deleteTransaction, students, teachers, personnel, classes } = useData();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Transaction | null>(null);
  const [deleting, setDeleting] = useState<Transaction | null>(null);
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), type: "", description: "", montant: 0, eleve_id: null as string | null, personnel_id: null as string | null });
  const [filter, setFilter] = useState<"all" | string>("all");
  const [search, setSearch] = useState("");
  const [filterClasse, setFilterClasse] = useState("");
  const [formFilterClasse, setFormFilterClasse] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [historyStudentId, setHistoryStudentId] = useState("");

  // DB-backed payment types
  const [paymentTypes, setPaymentTypes] = useState<PaymentType[]>([]);
  const [showTypeManager, setShowTypeManager] = useState(false);
  const [typeForm, setTypeForm] = useState({ label: "", direction: "in" as "in" | "out" });
  const [editingType, setEditingType] = useState<PaymentType | null>(null);

  const fetchTypes = useCallback(async () => {
    const { data } = await supabase.from("payment_types").select("*").order("created_at");
    if (data) setPaymentTypes(data.map((d: any) => ({ id: d.id, key: d.key, label: d.label, direction: d.direction as "in" | "out", color: d.color })));
  }, []);

  useEffect(() => { fetchTypes(); }, [fetchTypes]);

  const addType = async () => {
    if (!typeForm.label.trim()) return;
    const key = typeForm.label.trim().toLowerCase().replace(/\s+/g, "_");
    const color = typeForm.direction === "in" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800";
    if (editingType) {
      await supabase.from("payment_types").update({ key, label: typeForm.label.trim(), direction: typeForm.direction, color }).eq("id", editingType.id);
    } else {
      await supabase.from("payment_types").insert({ key, label: typeForm.label.trim(), direction: typeForm.direction, color });
    }
    setTypeForm({ label: "", direction: "in" });
    setEditingType(null);
    fetchTypes();
  };

  const deleteType = async (id: string) => {
    await supabase.from("payment_types").delete().eq("id", id);
    fetchTypes();
  };

  const typeLabels = Object.fromEntries(paymentTypes.map(t => [t.key, t.label]));
  const typeColors = Object.fromEntries(paymentTypes.map(t => [t.key, t.color]));
  const inTypes = paymentTypes.filter(t => t.direction === "in").map(t => t.key);
  const outTypes = paymentTypes.filter(t => t.direction === "out").map(t => t.key);

  const getStudent = (id: string | null) => id ? students.find(s => s.id === id) || null : null;

  const filtered = transactions.filter((t) => {
    const matchType = filter === "all" || t.type === filter;
    const student = getStudent(t.eleve_id);
    const q = search.toLowerCase();
    const matchSearch = !search || t.description.toLowerCase().includes(q) || (student?.nom || "").toLowerCase().includes(q) || (student?.matricule || "").toLowerCase().includes(q);
    const matchClasse = !filterClasse || (student && student.classe === filterClasse);
    return matchType && matchSearch && matchClasse;
  });

  const totalRecettes = transactions.filter((t) => inTypes.includes(t.type)).reduce((a, b) => a + b.montant, 0);
  const totalDepenses = transactions.filter((t) => outTypes.includes(t.type)).reduce((a, b) => a + b.montant, 0);
  const solde = totalRecettes - totalDepenses;

  // Students filtered by class in transaction form
  const formStudents = useMemo(() => {
    if (!formFilterClasse) return students;
    return students.filter(s => s.classe === formFilterClasse);
  }, [formFilterClasse, students]);

  const openAdd = () => {
    setEditing(null);
    setFormFilterClasse("");
    setForm({ date: new Date().toISOString().slice(0, 10), type: paymentTypes[0]?.key || "", description: "", montant: 0, eleve_id: null, personnel_id: null });
    setModalOpen(true);
  };
  const openEdit = (t: Transaction) => {
    setEditing(t);
    const student = getStudent(t.eleve_id);
    setFormFilterClasse(student?.classe || "");
    setForm({ date: t.date, type: t.type, description: t.description, montant: t.montant, eleve_id: t.eleve_id, personnel_id: t.personnel_id });
    setModalOpen(true);
  };

  const handleSave = async () => {
    if (!form.type || !form.description.trim() || form.montant <= 0) return;
    if (editing) await updateTransaction({ ...editing, ...form });
    else await addTransaction(form);
    setModalOpen(false);
  };

  const handleDelete = async () => { if (deleting) { await deleteTransaction(deleting.id); setDeleting(null); } };

  // Payment history per student
  const historyStudent = useMemo(() => students.find(s => s.id === historyStudentId) || null, [historyStudentId, students]);
  const historyTransactions = useMemo(() => {
    if (!historyStudentId) return [];
    return transactions.filter(t => t.eleve_id === historyStudentId).sort((a, b) => b.date.localeCompare(a.date));
  }, [historyStudentId, transactions]);
  const historyTotalPaid = useMemo(() => historyTransactions.filter(t => inTypes.includes(t.type)).reduce((a, b) => a + b.montant, 0), [historyTransactions, inTypes]);

  // WhatsApp reminder for unpaid students
  const sendWhatsAppReminder = (student: typeof students[0]) => {
    if (!student.tel_parent) return;
    const phone = student.tel_parent.replace(/\D/g, "");
    const msg = encodeURIComponent(`Cher parent de ${student.nom} (${student.classe}), nous vous rappelons que les frais scolaires de votre enfant n'ont pas encore été réglés. Merci de passer à la direction. — Complexe Scolaire TURUNGA`);
    window.open(`https://wa.me/${phone}?text=${msg}`, "_blank");
  };

  const unpaidStudents = useMemo(() => {
    return students.filter(s => {
      const paid = transactions.filter(t => t.eleve_id === s.id && inTypes.includes(t.type)).reduce((a, b) => a + b.montant, 0);
      return paid === 0;
    });
  }, [students, transactions, inTypes]);

  const esc = (s: unknown) =>
    String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");

  const printReceipt = (tx: Transaction) => {
    const student = getStudent(tx.eleve_id);
    const w = window.open("", "_blank", "width=420,height=650");
    if (!w) return;
    w.document.write(`<html><head><title>Reçu</title><style>
      body{font-family:'Segoe UI',Arial,sans-serif;padding:24px;max-width:380px;margin:0 auto;color:#1a1a1a}
      h2{text-align:center;margin:0 0 2px;font-size:18px}
      .sub{text-align:center;font-size:11px;color:#888;margin-bottom:20px;border-bottom:2px solid #e5e5e5;padding-bottom:12px}
      .row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px dashed #ddd;font-size:13px}
      .label{font-weight:600;color:#555}
      .total{font-size:22px;font-weight:800;text-align:center;margin:20px 0;padding:14px;background:linear-gradient(135deg,#f0fdf4,#ecfdf5);border-radius:12px;color:#16a34a}
      .sig{margin-top:50px;display:flex;justify-content:space-between}
      .sig div{text-align:center;width:45%}
      .sig-line{border-top:2px solid #333;margin-top:50px;padding-top:6px;font-size:11px;color:#555}
      .footer{text-align:center;font-size:9px;color:#bbb;margin-top:24px}
    </style></head><body>
      <h2>Complexe Scolaire TURUNGA</h2>
      <div class="sub">REÇU DE PAIEMENT</div>
      <div class="row"><span class="label">Date</span><span>${esc(tx.date)}</span></div>
      <div class="row"><span class="label">Type</span><span>${esc(typeLabels[tx.type] || tx.type)}</span></div>
      <div class="row"><span class="label">Description</span><span>${esc(tx.description)}</span></div>
      ${student ? `
        <div class="row"><span class="label">Élève</span><span>${esc(student.nom)}</span></div>
        <div class="row"><span class="label">Matricule</span><span>${esc(student.matricule || "—")}</span></div>
        <div class="row"><span class="label">Classe</span><span>${esc(student.classe)}</span></div>
      ` : ""}
      <div class="total">${esc(tx.montant.toLocaleString())} FC</div>
      <div class="sig"><div><div class="sig-line">Le Payeur</div></div><div><div class="sig-line">La Direction</div></div></div>
      <div class="footer">Complexe Scolaire TURUNGA — Document officiel</div>
    </body></html>`);
    w.document.close();
    w.print();
  };

  const inputClass = "w-full rounded-xl border border-input bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-shadow";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Comptabilité</h1>
          <p className="text-sm text-muted-foreground">Gestion financière de l'établissement</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => { setShowHistory(!showHistory); setShowTypeManager(false); }} className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${showHistory ? "bg-primary text-primary-foreground shadow-md" : "border border-border text-foreground hover:bg-muted"}`}>
            <History className="h-4 w-4" /> Historique élève
          </button>
          <button onClick={() => { setShowTypeManager(!showTypeManager); setShowHistory(false); }} className={`inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${showTypeManager ? "bg-primary text-primary-foreground shadow-md" : "border border-border text-foreground hover:bg-muted"}`}>
            <Settings className="h-4 w-4" /> Types de paiement
          </button>
          <PrintButton title="Rapport Comptabilité" contentId="comptabilite-table" />
          <button onClick={openAdd} className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow-md hover:bg-primary/90 transition-all hover:shadow-lg">
            <Plus className="h-4 w-4" /> Nouvelle transaction
          </button>
        </div>
      </div>

      {/* Payment History per Student */}
      {showHistory && (
        <div className="rounded-2xl border border-border bg-card p-5 animate-fade-in space-y-4 shadow-sm">
          <h3 className="font-semibold text-foreground">Historique des paiements par élève</h3>
          <div className="flex gap-3 flex-wrap items-end">
            <div className="min-w-[140px]">
              <label className="text-xs font-medium text-muted-foreground">Classe</label>
              <select value={formFilterClasse} onChange={e => { setFormFilterClasse(e.target.value); setHistoryStudentId(""); }} className={inputClass}>
                <option value="">Toutes</option>
                {classes.map(c => <option key={c.id} value={c.nom}>{c.nom}</option>)}
              </select>
            </div>
            <div className="flex-1 min-w-[200px]">
              <label className="text-xs font-medium text-muted-foreground">Élève</label>
              <select value={historyStudentId} onChange={e => setHistoryStudentId(e.target.value)} className={inputClass}>
                <option value="">-- Sélectionner --</option>
                {(formFilterClasse ? students.filter(s => s.classe === formFilterClasse) : students).map(s => (
                  <option key={s.id} value={s.id}>{s.nom} ({s.classe}) {s.matricule ? `- ${s.matricule}` : ""}</option>
                ))}
              </select>
            </div>
          </div>

          {historyStudent && (
            <div className="space-y-3">
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="rounded-xl bg-muted px-4 py-2"><span className="text-muted-foreground">Élève:</span> <span className="font-semibold text-foreground">{historyStudent.nom}</span></div>
                <div className="rounded-xl bg-muted px-4 py-2"><span className="text-muted-foreground">Matricule:</span> <span className="font-semibold text-foreground">{historyStudent.matricule || "—"}</span></div>
                <div className="rounded-xl bg-muted px-4 py-2"><span className="text-muted-foreground">Classe:</span> <span className="font-semibold text-foreground">{historyStudent.classe}</span></div>
                <div className="rounded-xl bg-green-100 px-4 py-2"><span className="text-green-800 font-semibold">Total payé: {historyTotalPaid.toLocaleString()} FC</span></div>
              </div>
              <div className="overflow-x-auto rounded-xl border border-border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border bg-muted/50">
                      <th className="px-4 py-2.5 text-left font-semibold text-muted-foreground">Date</th>
                      <th className="px-4 py-2.5 text-left font-semibold text-muted-foreground">Type</th>
                      <th className="px-4 py-2.5 text-left font-semibold text-muted-foreground">Description</th>
                      <th className="px-4 py-2.5 text-right font-semibold text-muted-foreground">Montant</th>
                    </tr>
                  </thead>
                  <tbody>
                    {historyTransactions.map(t => (
                      <tr key={t.id} className="border-b border-border/50 last:border-0">
                        <td className="px-4 py-2.5 text-muted-foreground">{t.date}</td>
                        <td className="px-4 py-2.5"><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${typeColors[t.type] || "bg-muted text-foreground"}`}>{typeLabels[t.type] || t.type}</span></td>
                        <td className="px-4 py-2.5 text-foreground">{t.description}</td>
                        <td className={`px-4 py-2.5 text-right font-bold ${inTypes.includes(t.type) ? "text-success" : "text-destructive"}`}>{t.montant.toLocaleString()} FC</td>
                      </tr>
                    ))}
                    {historyTransactions.length === 0 && <tr><td colSpan={4} className="px-4 py-6 text-center text-muted-foreground">Aucun paiement trouvé</td></tr>}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* WhatsApp reminders for unpaid students */}
          {unpaidStudents.length > 0 && (
            <div className="border-t border-border pt-4">
              <h4 className="text-sm font-semibold text-destructive mb-2">Élèves sans paiement ({unpaidStudents.length})</h4>
              <div className="max-h-40 overflow-y-auto space-y-1">
                {unpaidStudents.slice(0, 20).map(s => (
                  <div key={s.id} className="flex items-center justify-between text-sm py-1.5 px-3 rounded-lg hover:bg-muted/50">
                    <span className="text-foreground">{s.nom} <span className="text-muted-foreground">({s.classe})</span></span>
                    {s.tel_parent && (
                      <button onClick={() => sendWhatsAppReminder(s)} className="inline-flex items-center gap-1 rounded-lg bg-green-600 px-3 py-1 text-xs font-medium text-white hover:bg-green-700 transition-colors">
                        <MessageSquare className="h-3 w-3" /> Rappel
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {showTypeManager && (
        <div className="rounded-2xl border border-border bg-card p-5 animate-fade-in space-y-4 shadow-sm">
          <h3 className="font-semibold text-foreground">Gérer les types de paiement</h3>
          <div className="flex flex-wrap gap-2">
            {paymentTypes.map(t => (
              <div key={t.id} className="flex items-center gap-2 rounded-xl border border-border bg-background px-3 py-2 text-sm shadow-sm">
                <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${t.color}`}>{t.label}</span>
                <span className="text-xs text-muted-foreground">({t.direction === "in" ? "Entrée" : "Sortie"})</span>
                <button onClick={() => { setEditingType(t); setTypeForm({ label: t.label, direction: t.direction }); }} className="p-1 text-muted-foreground hover:text-foreground"><Pencil className="h-3 w-3" /></button>
                <button onClick={() => deleteType(t.id)} className="p-1 text-muted-foreground hover:text-destructive"><Trash2 className="h-3 w-3" /></button>
              </div>
            ))}
          </div>
          <div className="flex gap-3 flex-wrap items-end">
            <div className="flex-1 min-w-[160px]">
              <label className="text-xs font-medium text-muted-foreground">Libellé</label>
              <input value={typeForm.label} onChange={e => setTypeForm({ ...typeForm, label: e.target.value })} className={inputClass} placeholder="ex: Frais de souche" />
            </div>
            <div className="min-w-[140px]">
              <label className="text-xs font-medium text-muted-foreground">Direction</label>
              <select value={typeForm.direction} onChange={e => setTypeForm({ ...typeForm, direction: e.target.value as "in" | "out" })} className={inputClass}>
                <option value="in">Entrée (recette)</option>
                <option value="out">Sortie (dépense)</option>
              </select>
            </div>
            <button onClick={addType} className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">
              {editingType ? "Modifier" : "Ajouter"}
            </button>
            {editingType && (
              <button onClick={() => { setEditingType(null); setTypeForm({ label: "", direction: "in" }); }} className="rounded-xl border border-border px-4 py-2.5 text-sm text-foreground hover:bg-muted">Annuler</button>
            )}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {[
          { label: "Total Recettes", value: totalRecettes, icon: TrendingUp, bg: "bg-success/10", iconColor: "text-success", valueColor: "text-success" },
          { label: "Total Dépenses", value: totalDepenses, icon: TrendingDown, bg: "bg-destructive/10", iconColor: "text-destructive", valueColor: "text-destructive" },
          { label: "Solde", value: solde, icon: Wallet, bg: "bg-info/10", iconColor: "text-info", valueColor: solde >= 0 ? "text-success" : "text-destructive" },
        ].map((card, i) => (
          <div key={i} className="rounded-2xl border border-border bg-card p-5 shadow-sm animate-fade-in hover:shadow-md transition-shadow">
            <div className="flex items-center gap-3">
              <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${card.bg}`}>
                <card.icon className={`h-5 w-5 ${card.iconColor}`} />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{card.label}</p>
                <p className={`text-xl font-bold ${card.valueColor}`}>{card.value.toLocaleString()} FC</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative max-w-xs flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input type="text" placeholder="Rechercher..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-xl border border-input bg-card py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40" />
        </div>
        <select value={filterClasse} onChange={e => setFilterClasse(e.target.value)} className="rounded-xl border border-input bg-card px-4 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40">
          <option value="">Toutes les classes</option>
          {classes.map(c => <option key={c.id} value={c.nom}>{c.nom}</option>)}
        </select>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setFilter("all")} className={`rounded-xl px-4 py-2 text-sm font-medium transition-all ${filter === "all" ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>Tout</button>
          {paymentTypes.map((t) => (
            <button key={t.key} onClick={() => setFilter(t.key)} className={`rounded-xl px-4 py-2 text-sm font-medium transition-all ${filter === t.key ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-muted/80"}`}>{t.label}</button>
          ))}
        </div>
      </div>

      <div id="comptabilite-table" className="rounded-2xl border border-border bg-card shadow-sm animate-fade-in overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50 text-left">
                <th className="px-5 py-3.5 font-semibold text-muted-foreground">Date</th>
                <th className="px-5 py-3.5 font-semibold text-muted-foreground">Type</th>
                <th className="px-5 py-3.5 font-semibold text-muted-foreground">Description</th>
                <th className="px-5 py-3.5 font-semibold text-muted-foreground">Élève</th>
                <th className="px-5 py-3.5 font-semibold text-muted-foreground text-right">Montant</th>
                <th className="px-5 py-3.5 font-semibold text-muted-foreground no-print">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((t) => {
                const student = getStudent(t.eleve_id);
                return (
                  <tr key={t.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="px-5 py-3.5 text-muted-foreground">{t.date}</td>
                    <td className="px-5 py-3.5"><span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${typeColors[t.type] || "bg-muted text-foreground"}`}>{typeLabels[t.type] || t.type}</span></td>
                    <td className="px-5 py-3.5 font-medium text-foreground">{t.description}</td>
                    <td className="px-5 py-3.5 text-muted-foreground">{student ? `${student.nom} (${student.classe})` : "—"}</td>
                    <td className={`px-5 py-3.5 text-right font-bold ${inTypes.includes(t.type) ? "text-success" : "text-destructive"}`}>
                      {inTypes.includes(t.type) ? "+" : "-"}{t.montant.toLocaleString()} FC
                    </td>
                    <td className="px-5 py-3.5 no-print">
                      <div className="flex gap-1">
                        <button onClick={() => printReceipt(t)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors" title="Reçu"><Printer className="h-4 w-4" /></button>
                        <button onClick={() => openEdit(t)} className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"><Pencil className="h-4 w-4" /></button>
                        <button onClick={() => setDeleting(t)} className="rounded-lg p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="px-5 py-10 text-center text-muted-foreground">Aucune transaction trouvée</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <CrudModal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Modifier la transaction" : "Nouvelle transaction"}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Date</label>
              <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className={inputClass} />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Type</label>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} className={inputClass}>
                <option value="">-- Sélectionner --</option>
                {paymentTypes.map(t => (<option key={t.key} value={t.key}>{t.label}</option>))}
              </select>
            </div>
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-foreground">Description</label>
            <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className={inputClass} placeholder="Description de la transaction" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-foreground">Montant (FC)</label>
            <input type="number" value={form.montant} onChange={(e) => setForm({ ...form, montant: Number(e.target.value) })} className={inputClass} min={0} />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-foreground">Filtrer par classe</label>
            <select value={formFilterClasse} onChange={e => { setFormFilterClasse(e.target.value); setForm({ ...form, eleve_id: null }); }} className={inputClass}>
              <option value="">Toutes les classes</option>
              {classes.map(c => <option key={c.id} value={c.nom}>{c.nom}</option>)}
            </select>
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-foreground">Élève (optionnel)</label>
            <select value={form.eleve_id || ""} onChange={(e) => setForm({ ...form, eleve_id: e.target.value || null })} className={inputClass}>
              <option value="">-- Sélectionner un élève --</option>
              {formStudents.map((s) => (<option key={s.id} value={s.id}>{s.nom} ({s.classe}) {s.matricule ? `- ${s.matricule}` : ""}</option>))}
            </select>
          </div>
          {outTypes.includes(form.type) && (
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Personnel (optionnel)</label>
              <select value={form.personnel_id || ""} onChange={(e) => setForm({ ...form, personnel_id: e.target.value || null })} className={inputClass}>
                <option value="">-- Aucun --</option>
                {[...teachers.map(t => ({ id: t.id, nom: t.nom, type: "Enseignant" })), ...personnel.map(p => ({ id: p.id, nom: p.nom, type: "Personnel" }))].map((p) => (
                  <option key={p.id} value={p.id}>{p.nom} ({p.type})</option>
                ))}
              </select>
            </div>
          )}
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-xl border border-border px-5 py-2.5 text-sm font-medium text-foreground hover:bg-muted transition-colors">Annuler</button>
            <button onClick={handleSave} className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">{editing ? "Modifier" : "Ajouter"}</button>
          </div>
        </div>
      </CrudModal>

      <DeleteConfirm open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete} name={deleting?.description || ""} />
    </div>
  );
};

export default Comptabilite;
