import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { useSchoolYear, type SchoolYear } from "@/contexts/SchoolYearContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { CalendarDays, Plus, CheckCircle2, Trash2, Copy, Pencil, Archive, ArchiveRestore } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

const emptyForm = { name: "", start_date: "", end_date: "", passing_score: 50 };

export default function SchoolYears() {
  const { user } = useAuth();
  const { years, activeYear, selectedYearId, setSelectedYearId, refresh } = useSchoolYear();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<SchoolYear | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [copyOpen, setCopyOpen] = useState(false);
  const [copySource, setCopySource] = useState<string>("");
  const [copyTarget, setCopyTarget] = useState<string>("");
  const [copyOptions, setCopyOptions] = useState({
    classes: true, courses: true, fee_structures: true, students: false,
  });
  const [busy, setBusy] = useState(false);

  if (user?.role !== "admin") {
    return <div className="text-muted-foreground">Accès réservé à l'administrateur.</div>;
  }

  const openCreate = () => { setEditing(null); setForm(emptyForm); setOpen(true); };
  const openEdit = (y: SchoolYear) => {
    setEditing(y);
    setForm({ name: y.name, start_date: y.start_date, end_date: y.end_date, passing_score: Number(y.passing_score) });
    setOpen(true);
  };

  const save = async () => {
    if (!form.name || !form.start_date || !form.end_date) {
      toast({ title: "Champs requis", description: "Nom et dates obligatoires", variant: "destructive" });
      return;
    }
    setBusy(true);
    if (editing) {
      const { error } = await supabase.from("school_years").update(form).eq("id", editing.id);
      if (error) toast({ title: "Erreur", description: error.message, variant: "destructive" });
      else toast({ title: "Année mise à jour" });
    } else {
      const { error } = await supabase.from("school_years").insert(form);
      if (error) toast({ title: "Erreur", description: error.message, variant: "destructive" });
      else toast({ title: "Année créée" });
    }
    setBusy(false);
    setOpen(false);
    await refresh();
  };

  const activate = async (id: string) => {
    setBusy(true);
    // Archiver automatiquement l'ancienne année active avant d'activer la nouvelle
    const previous = years.find((y) => y.is_active && y.id !== id);
    const { error } = await supabase.rpc("set_active_school_year", { _school_year_id: id });
    if (error) {
      toast({ title: "Erreur", description: error.message, variant: "destructive" });
    } else {
      if (previous) {
        await supabase.rpc("archive_school_year", { _school_year_id: previous.id, _archive: true });
        toast({ title: "Année activée", description: `${previous.name} a été archivée automatiquement.` });
      } else {
        toast({ title: "Année activée" });
      }
      setSelectedYearId(id);
    }
    setBusy(false);
    await refresh();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from("school_years").delete().eq("id", id);
    if (error) toast({ title: "Erreur", description: error.message, variant: "destructive" });
    else toast({ title: "Année supprimée" });
    await refresh();
  };

  const toggleArchive = async (y: SchoolYear) => {
    const archive = !(y as any).is_archived;
    setBusy(true);
    const { error } = await supabase.rpc("archive_school_year", { _school_year_id: y.id, _archive: archive });
    setBusy(false);
    if (error) toast({ title: "Erreur", description: error.message, variant: "destructive" });
    else toast({ title: archive ? "Année archivée" : "Année désarchivée" });
    await refresh();
  };

  const runCopy = async () => {
    if (!copySource || !copyTarget || copySource === copyTarget) {
      toast({ title: "Sélection invalide", description: "Choisissez deux années différentes", variant: "destructive" });
      return;
    }
    setBusy(true);
    const { data, error } = await supabase.rpc("copy_school_year_data", {
      _source_id: copySource,
      _target_id: copyTarget,
      _copy_classes: copyOptions.classes,
      _copy_courses: copyOptions.courses,
      _copy_fees: copyOptions.fee_structures,
      _copy_students: copyOptions.students,
    });
    setBusy(false);
    if (error) toast({ title: "Erreur de copie", description: error.message, variant: "destructive" });
    else {
      toast({ title: "Données copiées", description: `${data ?? 0} enregistrement(s) créé(s)` });
      setCopyOpen(false);
    }
    await refresh();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold">
            <CalendarDays className="h-6 w-6 text-primary" /> Années scolaires
          </h1>
          <p className="text-sm text-muted-foreground">
            Gérez vos années scolaires, activez celle en cours et copiez les données.
          </p>
        </div>
        <div className="flex gap-2">
          <Dialog open={copyOpen} onOpenChange={setCopyOpen}>
            <DialogTrigger asChild>
              <Button variant="outline"><Copy className="mr-2 h-4 w-4" /> Copier données</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Copier vers une nouvelle année</DialogTitle></DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Année source</Label>
                  <select className="mt-1 w-full rounded-md border border-input bg-background p-2"
                    value={copySource} onChange={(e) => setCopySource(e.target.value)}>
                    <option value="">— Choisir —</option>
                    {years.map((y) => <option key={y.id} value={y.id}>{y.name}</option>)}
                  </select>
                </div>
                <div>
                  <Label>Année cible</Label>
                  <select className="mt-1 w-full rounded-md border border-input bg-background p-2"
                    value={copyTarget} onChange={(e) => setCopyTarget(e.target.value)}>
                    <option value="">— Choisir —</option>
                    {years.map((y) => <option key={y.id} value={y.id}>{y.name}</option>)}
                  </select>
                </div>
                <div className="space-y-2 rounded-lg border p-3">
                  <p className="text-sm font-medium">Éléments à copier :</p>
                  {[
                    { k: "classes", l: "Classes" },
                    { k: "courses", l: "Cours" },
                    { k: "fee_structures", l: "Structure de prix" },
                    { k: "students", l: "Élèves (réinscrire dans la nouvelle année)" },
                  ].map((o) => (
                    <label key={o.k} className="flex items-center gap-2 text-sm">
                      <Checkbox
                        checked={(copyOptions as any)[o.k]}
                        onCheckedChange={(v) => setCopyOptions((p) => ({ ...p, [o.k]: !!v }))}
                      />
                      {o.l}
                    </label>
                  ))}
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setCopyOpen(false)}>Annuler</Button>
                <Button onClick={runCopy} disabled={busy}>Copier</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" /> Nouvelle année</Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>{editing ? "Modifier" : "Créer"} une année scolaire</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div>
                  <Label>Nom (ex: 2025-2026)</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Date début</Label>
                    <Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
                  </div>
                  <div>
                    <Label>Date fin</Label>
                    <Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
                  </div>
                </div>
                <div>
                  <Label>Score de passage (%)</Label>
                  <Input type="number" value={form.passing_score}
                    onChange={(e) => setForm({ ...form, passing_score: Number(e.target.value) })} />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setOpen(false)}>Annuler</Button>
                <Button onClick={save} disabled={busy}>Enregistrer</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {activeYear && (
        <Card className="border-primary/40 bg-primary/5">
          <CardContent className="flex items-center justify-between py-4">
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Année active</p>
              <p className="text-lg font-semibold">{activeYear.name}</p>
              <p className="text-xs text-muted-foreground">
                {activeYear.start_date} → {activeYear.end_date}
              </p>
            </div>
            <Badge className="bg-primary">En cours</Badge>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle>Liste des années</CardTitle></CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Période</TableHead>
                <TableHead>Score passage</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {years.length === 0 && (
                <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground">Aucune année scolaire</TableCell></TableRow>
              )}
              {years.map((y) => (
                <TableRow key={y.id} className={selectedYearId === y.id ? "bg-muted/40" : ""}>
                  <TableCell className="font-medium">{y.name}</TableCell>
                  <TableCell>{y.start_date} → {y.end_date}</TableCell>
                  <TableCell>{y.passing_score}%</TableCell>
                  <TableCell>
                    {y.is_active ? (
                      <Badge className="bg-green-600">Active</Badge>
                    ) : (y as any).is_archived ? (
                      <Badge variant="secondary" className="bg-amber-100 text-amber-800">Archivée</Badge>
                    ) : (
                      <Badge variant="outline">Inactive</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    {!y.is_active && (
                      <Button size="sm" variant="outline" onClick={() => activate(y.id)} disabled={busy}>
                        <CheckCircle2 className="mr-1 h-4 w-4" /> Activer
                      </Button>
                    )}
                    {!y.is_active && (
                      <Button size="sm" variant="outline" onClick={() => toggleArchive(y)} disabled={busy} title={(y as any).is_archived ? "Désarchiver" : "Archiver"}>
                        {(y as any).is_archived ? <ArchiveRestore className="h-4 w-4" /> : <Archive className="h-4 w-4" />}
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => openEdit(y)}>
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="ghost" className="text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Supprimer cette année ?</AlertDialogTitle>
                          <AlertDialogDescription>
                            L'historique rattaché restera mais l'année ne pourra plus être sélectionnée.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Annuler</AlertDialogCancel>
                          <AlertDialogAction onClick={() => remove(y.id)}>Supprimer</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
