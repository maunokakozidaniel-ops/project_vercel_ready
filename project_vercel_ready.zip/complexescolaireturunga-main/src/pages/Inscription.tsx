import { useState } from "react";
import { UserPlus, CheckCircle, ArrowRight } from "lucide-react";
import { useData } from "@/contexts/DataContext";

const Inscription = () => {
  const { addStudent, classes } = useData();
  const [step, setStep] = useState(1);
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState({
    nom: "", sexe: "M", classe: "", naissance: "", parent: "", adresse: "", tel_parent: "",
  });

  const classesList = classes.map(c => c.nom);
  const inputClass = "w-full rounded-xl border border-input bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-shadow";

  const canNext = () => {
    if (step === 1) return form.nom.trim() && form.sexe && form.naissance;
    if (step === 2) return form.classe;
    return true;
  };

  const handleSubmit = async () => {
    if (!form.nom.trim() || !form.classe) return;
    await addStudent({ ...form, matricule: null });
    setSuccess(true);
  };

  const reset = () => {
    setForm({ nom: "", sexe: "M", classe: "", naissance: "", parent: "", adresse: "", tel_parent: "" });
    setStep(1);
    setSuccess(false);
  };

  if (success) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="text-center animate-fade-in space-y-4">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-success/10">
            <CheckCircle className="h-10 w-10 text-success" />
          </div>
          <h2 className="text-2xl font-bold text-foreground">Inscription réussie !</h2>
          <p className="text-muted-foreground">L'élève <strong>{form.nom}</strong> a été inscrit en <strong>{form.classe}</strong>.</p>
          <button onClick={reset} className="rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">
            Nouvelle inscription
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div className="text-center">
        <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10">
          <UserPlus className="h-7 w-7 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-foreground">Inscription d'un nouvel élève</h1>
        <p className="text-sm text-muted-foreground mt-1">Remplissez les informations de l'élève étape par étape</p>
      </div>

      {/* Progress */}
      <div className="flex items-center justify-center gap-2">
        {[1, 2, 3].map(s => (
          <div key={s} className="flex items-center gap-2">
            <div className={`flex h-9 w-9 items-center justify-center rounded-full text-sm font-bold transition-colors ${step >= s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}>{s}</div>
            {s < 3 && <div className={`h-0.5 w-8 rounded-full transition-colors ${step > s ? "bg-primary" : "bg-border"}`} />}
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-border bg-card p-6 shadow-sm animate-fade-in">
        {step === 1 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Informations personnelles</h2>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Nom complet *</label>
              <input value={form.nom} onChange={e => setForm({ ...form, nom: e.target.value })} className={inputClass} placeholder="Nom complet de l'élève" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-foreground">Sexe *</label>
                <select value={form.sexe} onChange={e => setForm({ ...form, sexe: e.target.value })} className={inputClass}>
                  <option value="M">Masculin</option>
                  <option value="F">Féminin</option>
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-foreground">Date de naissance *</label>
                <input type="date" value={form.naissance} onChange={e => setForm({ ...form, naissance: e.target.value })} className={inputClass} />
              </div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Classe et adresse</h2>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Classe *</label>
              <select value={form.classe} onChange={e => setForm({ ...form, classe: e.target.value })} className={inputClass}>
                <option value="">-- Sélectionner une classe --</option>
                {classesList.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Adresse</label>
              <input value={form.adresse} onChange={e => setForm({ ...form, adresse: e.target.value })} className={inputClass} placeholder="Adresse de l'élève" />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Informations du parent/tuteur</h2>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Nom du parent/tuteur</label>
              <input value={form.parent} onChange={e => setForm({ ...form, parent: e.target.value })} className={inputClass} placeholder="Nom du parent ou tuteur" />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-foreground">Téléphone du parent</label>
              <input value={form.tel_parent} onChange={e => setForm({ ...form, tel_parent: e.target.value })} className={inputClass} placeholder="+243 ..." />
            </div>
          </div>
        )}

        <div className="mt-6 flex justify-between">
          {step > 1 ? (
            <button onClick={() => setStep(step - 1)} className="rounded-xl border border-border px-5 py-2.5 text-sm font-medium text-foreground hover:bg-muted transition-colors">Retour</button>
          ) : <div />}
          {step < 3 ? (
            <button onClick={() => canNext() && setStep(step + 1)} disabled={!canNext()} className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50">
              Suivant <ArrowRight className="h-4 w-4" />
            </button>
          ) : (
            <button onClick={handleSubmit} disabled={!form.nom.trim() || !form.classe} className="inline-flex items-center gap-2 rounded-xl bg-success px-5 py-2.5 text-sm font-semibold text-success-foreground hover:bg-success/90 transition-colors disabled:opacity-50">
              <UserPlus className="h-4 w-4" /> Inscrire l'élève
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Inscription;
