import { Search, Plus, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import { useData, Teacher } from "@/contexts/DataContext";
import CrudModal from "@/components/CrudModal";
import DeleteConfirm from "@/components/DeleteConfirm";
import PrintButton from "@/components/PrintButton";

const emptyForm = { nom: "", matiere: "", classes: "", tel: "", statut: "actif", adresse: "", salaire: 0, genre: "M" };

const Teachers = () => {
  const { teachers, addTeacher, updateTeacher, deleteTeacher } = useData();
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Teacher | null>(null);
  const [deleting, setDeleting] = useState<Teacher | null>(null);
  const [form, setForm] = useState(emptyForm);

  const filtered = teachers.filter((t) => t.nom.toLowerCase().includes(search.toLowerCase()));

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (t: Teacher) => { setEditing(t); setForm({ nom: t.nom, matiere: t.matiere, classes: t.classes, tel: t.tel, statut: t.statut, adresse: t.adresse, salaire: t.salaire, genre: t.genre }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.nom.trim()) return;
    if (editing) await updateTeacher({ ...editing, ...form });
    else await addTeacher(form);
    setModalOpen(false);
  };

  const handleDelete = async () => { if (deleting) { await deleteTeacher(deleting.id); setDeleting(null); } };

  const inputClass = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  const statusColor = (s: string) => s === "actif" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Enseignants</h1>
          <p className="text-sm text-muted-foreground">Corps enseignant ({teachers.length})</p>
        </div>
        <div className="flex gap-2">
          <PrintButton title="Liste des Enseignants" contentId="teachers-list" />
          <button onClick={openAdd} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            <Plus className="h-4 w-4" />
            Nouvel enseignant
          </button>
        </div>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input type="text" placeholder="Rechercher un enseignant..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-lg border border-input bg-card py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
      </div>

      <div id="teachers-list" className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((t) => (
          <div key={t.id} className="rounded-xl border border-border bg-card p-5 transition-shadow hover:shadow-md animate-fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                  {t.nom.split(" ").slice(1).map(n => n[0]).join("")}
                </div>
                <div>
                  <p className="font-semibold text-foreground">{t.nom}</p>
                  <p className="text-xs text-muted-foreground">{t.matiere}</p>
                </div>
              </div>
              <div className="flex gap-1 no-print">
                <button onClick={() => openEdit(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"><Pencil className="h-4 w-4" /></button>
                <button onClick={() => setDeleting(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
              </div>
            </div>
            <div className="mt-4 space-y-1.5 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Classes</span>
                <span className="font-medium text-foreground">{t.classes}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Téléphone</span>
                <span className="font-medium text-foreground">{t.tel}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Genre</span>
                <span className="font-medium text-foreground">{t.genre === "M" ? "Masculin" : "Féminin"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Salaire</span>
                <span className="font-medium text-foreground">{t.salaire.toLocaleString()} FC</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Statut</span>
                <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${statusColor(t.statut)}`}>{t.statut === "actif" ? "Actif" : "Inactif"}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <CrudModal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Modifier l'enseignant" : "Nouvel enseignant"}>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Nom complet</label>
            <input value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} className={inputClass} placeholder="Prof. Nom Prénom" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Genre</label>
              <select value={form.genre} onChange={(e) => setForm({ ...form, genre: e.target.value })} className={inputClass}>
                <option value="M">Masculin</option>
                <option value="F">Féminin</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Matière</label>
              <input value={form.matiere} onChange={(e) => setForm({ ...form, matiere: e.target.value })} className={inputClass} placeholder="Ex: Mathématiques" />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Classes assignées</label>
            <input value={form.classes} onChange={(e) => setForm({ ...form, classes: e.target.value })} className={inputClass} placeholder="Ex: 6ème A, 5ème B" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Téléphone</label>
              <input value={form.tel} onChange={(e) => setForm({ ...form, tel: e.target.value })} className={inputClass} placeholder="+243 ..." />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Salaire (FC)</label>
              <input type="number" value={form.salaire} onChange={(e) => setForm({ ...form, salaire: Number(e.target.value) })} className={inputClass} />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Adresse</label>
            <input value={form.adresse} onChange={(e) => setForm({ ...form, adresse: e.target.value })} className={inputClass} placeholder="Adresse" />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Statut</label>
            <select value={form.statut} onChange={(e) => setForm({ ...form, statut: e.target.value })} className={inputClass}>
              <option value="actif">Actif</option>
              <option value="inactif">Inactif</option>
            </select>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors">Annuler</button>
            <button onClick={handleSave} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">{editing ? "Modifier" : "Ajouter"}</button>
          </div>
        </div>
      </CrudModal>

      <DeleteConfirm open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete} name={deleting?.nom || ""} />
    </div>
  );
};

export default Teachers;
