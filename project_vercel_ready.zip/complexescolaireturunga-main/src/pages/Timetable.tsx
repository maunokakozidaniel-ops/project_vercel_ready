import { useState } from "react";
import { Plus, Pencil, Trash2, Clock } from "lucide-react";
import { useData, Timetable } from "@/contexts/DataContext";
import CrudModal from "@/components/CrudModal";
import DeleteConfirm from "@/components/DeleteConfirm";
import PrintButton from "@/components/PrintButton";

const jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
const emptyForm = { classe: "", jour: "Lundi", heure_debut: "07:30", heure_fin: "08:30", cours: "", enseignant: "", salle: "" };

const TimetablePage = () => {
  const { timetables, addTimetable, updateTimetable, deleteTimetable, classes, courses, teachers } = useData();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Timetable | null>(null);
  const [deleting, setDeleting] = useState<Timetable | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [filterClasse, setFilterClasse] = useState("");

  const classesList = classes.map(c => c.nom);
  const filtered = timetables.filter((t) => !filterClasse || t.classe === filterClasse);

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (t: Timetable) => { setEditing(t); setForm({ classe: t.classe, jour: t.jour, heure_debut: t.heure_debut, heure_fin: t.heure_fin, cours: t.cours, enseignant: t.enseignant, salle: t.salle }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.classe.trim() || !form.cours.trim()) return;
    if (editing) await updateTimetable({ ...editing, ...form });
    else await addTimetable(form);
    setModalOpen(false);
  };

  const handleDelete = async () => { if (deleting) { await deleteTimetable(deleting.id); setDeleting(null); } };

  const inputClass = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  // Group by day for display
  const byDay = jours.map((jour) => ({
    jour,
    items: filtered.filter((t) => t.jour === jour).sort((a, b) => a.heure_debut.localeCompare(b.heure_debut)),
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Emploi du temps</h1>
          <p className="text-sm text-muted-foreground">Horaires des cours ({timetables.length} créneaux)</p>
        </div>
        <div className="flex gap-2">
          <PrintButton title="Emploi du Temps" contentId="timetable-content" />
          <button onClick={openAdd} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            <Plus className="h-4 w-4" />
            Nouveau créneau
          </button>
        </div>
      </div>

      <div>
        <select value={filterClasse} onChange={(e) => setFilterClasse(e.target.value)} className="rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
          <option value="">Toutes les classes</option>
          {classesList.map((c) => (<option key={c} value={c}>{c}</option>))}
        </select>
      </div>

      <div id="timetable-content" className="space-y-4">
        {byDay.map(({ jour, items }) => (
          items.length > 0 && (
            <div key={jour} className="rounded-xl border border-border bg-card animate-fade-in">
              <div className="border-b border-border bg-muted/50 px-5 py-3">
                <h3 className="font-semibold text-foreground">{jour}</h3>
              </div>
              <div className="divide-y divide-border/50">
                {items.map((t) => (
                  <div key={t.id} className="flex items-center justify-between px-5 py-3 hover:bg-muted/30 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1.5 text-primary">
                        <Clock className="h-4 w-4" />
                        <span className="text-sm font-semibold">{t.heure_debut} - {t.heure_fin}</span>
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{t.cours}</p>
                        <p className="text-xs text-muted-foreground">{t.classe} • {t.enseignant} {t.salle && `• Salle: ${t.salle}`}</p>
                      </div>
                    </div>
                    <div className="flex gap-1 no-print">
                      <button onClick={() => openEdit(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"><Pencil className="h-4 w-4" /></button>
                      <button onClick={() => setDeleting(t)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )
        ))}
        {filtered.length === 0 && (
          <div className="rounded-xl border border-border bg-card p-10 text-center text-muted-foreground">
            Aucun créneau enregistré. {!filterClasse && "Sélectionnez une classe ou ajoutez un créneau."}
          </div>
        )}
      </div>

      <CrudModal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Modifier le créneau" : "Nouveau créneau"}>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Classe</label>
              <select value={form.classe} onChange={(e) => setForm({ ...form, classe: e.target.value })} className={inputClass}>
                <option value="">-- Sélectionner --</option>
                {classesList.map((c) => (<option key={c} value={c}>{c}</option>))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Jour</label>
              <select value={form.jour} onChange={(e) => setForm({ ...form, jour: e.target.value })} className={inputClass}>
                {jours.map((j) => (<option key={j} value={j}>{j}</option>))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Heure début</label>
              <input type="time" value={form.heure_debut} onChange={(e) => setForm({ ...form, heure_debut: e.target.value })} className={inputClass} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Heure fin</label>
              <input type="time" value={form.heure_fin} onChange={(e) => setForm({ ...form, heure_fin: e.target.value })} className={inputClass} />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Cours</label>
            <input value={form.cours} onChange={(e) => setForm({ ...form, cours: e.target.value })} className={inputClass} placeholder="Nom du cours" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Enseignant</label>
              <input value={form.enseignant} onChange={(e) => setForm({ ...form, enseignant: e.target.value })} className={inputClass} placeholder="Nom" />
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Salle</label>
              <input value={form.salle} onChange={(e) => setForm({ ...form, salle: e.target.value })} className={inputClass} placeholder="Ex: Salle A1" />
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors">Annuler</button>
            <button onClick={handleSave} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">{editing ? "Modifier" : "Ajouter"}</button>
          </div>
        </div>
      </CrudModal>

      <DeleteConfirm open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete} name={deleting?.cours || ""} />
    </div>
  );
};

export default TimetablePage;
