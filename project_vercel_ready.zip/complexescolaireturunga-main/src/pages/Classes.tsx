import { Users, Plus, Pencil, Trash2, Search } from "lucide-react";
import { useState } from "react";
import { useData, ClassType } from "@/contexts/DataContext";
import CrudModal from "@/components/CrudModal";
import DeleteConfirm from "@/components/DeleteConfirm";
import PrintButton from "@/components/PrintButton";

const emptyForm = { nom: "", section: "", capacite: 50, titulaire: "", annee_scolaire: "2025-2026" };

const Classes = () => {
  const { classes, addClass, updateClass, deleteClass, students } = useData();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<ClassType | null>(null);
  const [deleting, setDeleting] = useState<ClassType | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [search, setSearch] = useState("");
  const [filterSection, setFilterSection] = useState("");
  const [selectedClass, setSelectedClass] = useState<string | null>(null);

  const openAdd = () => { setEditing(null); setForm(emptyForm); setModalOpen(true); };
  const openEdit = (c: ClassType) => { setEditing(c); setForm({ nom: c.nom, section: c.section, capacite: c.capacite, titulaire: c.titulaire, annee_scolaire: c.annee_scolaire }); setModalOpen(true); };

  const handleSave = async () => {
    if (!form.nom.trim()) return;
    try {
      if (editing) await updateClass({ ...editing, ...form });
      else await addClass(form);
      setModalOpen(false);
    } catch (err) {
      console.error("Save class error:", err);
    }
  };

  const handleDelete = async () => { if (deleting) { await deleteClass(deleting.id); setDeleting(null); } };

  const getEffectif = (nom: string) => students.filter((s) => s.classe === nom).length;
  const getStudentsOfClass = (nom: string) => students.filter((s) => s.classe === nom);

  const sections = [...new Set(classes.map(c => c.section).filter(Boolean))].sort();

  const filtered = classes.filter((c) => {
    const q = search.toLowerCase();
    const matchSearch = c.nom.toLowerCase().includes(q) || c.titulaire.toLowerCase().includes(q);
    const matchSection = !filterSection || c.section === filterSection;
    return matchSearch && matchSection;
  });

  const inputClass = "w-full rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Classes</h1>
          <p className="text-sm text-muted-foreground">Organisation des classes ({classes.length})</p>
        </div>
        <div className="flex gap-2">
          <PrintButton title="Liste des Classes" contentId="classes-grid" />
          <button onClick={openAdd} className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90">
            <Plus className="h-4 w-4" />
            Nouvelle classe
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-3">
        <div className="relative max-w-xs flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input type="text" placeholder="Rechercher une classe ou un titulaire..." value={search} onChange={(e) => setSearch(e.target.value)} className="w-full rounded-lg border border-input bg-card py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring" />
        </div>
        <select value={filterSection} onChange={(e) => setFilterSection(e.target.value)} className="rounded-lg border border-input bg-card px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring">
          <option value="">Toutes les sections</option>
          {sections.map((s) => (<option key={s} value={s}>{s}</option>))}
        </select>
      </div>

      <div id="classes-grid" className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filtered.map((c) => (
          <div key={c.id} className={`group rounded-xl border bg-card p-5 transition-all hover:shadow-md animate-fade-in cursor-pointer ${selectedClass === c.nom ? "border-primary shadow-md" : "border-border hover:border-primary/30"}`} onClick={() => setSelectedClass(selectedClass === c.nom ? null : c.nom)}>
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-foreground">{c.nom}</h3>
              <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-semibold text-muted-foreground">{c.section}</span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{c.titulaire}</p>
            <div className="mt-3 space-y-1 text-sm">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" />
                <span className="font-semibold text-foreground">{getEffectif(c.nom)}</span>
                <span className="text-muted-foreground">/ {c.capacite} élèves</span>
              </div>
              <p className="text-xs text-muted-foreground">Année: {c.annee_scolaire}</p>
            </div>
            <div className="mt-3 flex gap-1 no-print" onClick={(e) => e.stopPropagation()}>
              <button onClick={() => openEdit(c)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"><Pencil className="h-4 w-4" /></button>
              <button onClick={() => setDeleting(c)} className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"><Trash2 className="h-4 w-4" /></button>
            </div>
          </div>
        ))}
      </div>

      {selectedClass && (
        <div className="rounded-xl border border-border bg-card p-5 animate-fade-in">
          <h3 className="text-lg font-bold text-foreground mb-3">Élèves de {selectedClass} ({getStudentsOfClass(selectedClass).length})</h3>
          {getStudentsOfClass(selectedClass).length === 0 ? (
            <p className="text-sm text-muted-foreground">Aucun élève dans cette classe</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50 text-left">
                    <th className="px-4 py-2 font-semibold text-muted-foreground">#</th>
                    <th className="px-4 py-2 font-semibold text-muted-foreground">Matricule</th>
                    <th className="px-4 py-2 font-semibold text-muted-foreground">Nom</th>
                    <th className="px-4 py-2 font-semibold text-muted-foreground">Sexe</th>
                    <th className="px-4 py-2 font-semibold text-muted-foreground">Parent</th>
                  </tr>
                </thead>
                <tbody>
                  {getStudentsOfClass(selectedClass).map((s, i) => (
                    <tr key={s.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30">
                      <td className="px-4 py-2 text-muted-foreground">{i + 1}</td>
                      <td className="px-4 py-2 font-mono text-xs text-primary">{s.matricule || "—"}</td>
                      <td className="px-4 py-2 font-medium text-foreground">{s.nom}</td>
                      <td className="px-4 py-2 text-muted-foreground">{s.sexe}</td>
                      <td className="px-4 py-2 text-muted-foreground">{s.parent}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      <CrudModal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? "Modifier la classe" : "Nouvelle classe"}>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Nom de la classe</label>
            <input value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} className={inputClass} placeholder="Ex: 6ème A" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Section</label>
              <select value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} className={inputClass}>
                <option value="">-- Sélectionner --</option>
                <option value="Scientifique">Scientifique</option>
                <option value="Littéraire">Littéraire</option>
                <option value="Commerciale">Commerciale</option>
                <option value="Pédagogique">Pédagogique</option>
                <option value="Technique">Technique</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-sm font-medium text-foreground">Capacité</label>
              <input type="number" value={form.capacite} onChange={(e) => setForm({ ...form, capacite: Number(e.target.value) })} className={inputClass} min={1} />
            </div>
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Professeur principal</label>
            <input value={form.titulaire} onChange={(e) => setForm({ ...form, titulaire: e.target.value })} className={inputClass} placeholder="Nom du professeur" />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-foreground">Année scolaire</label>
            <input value={form.annee_scolaire} onChange={(e) => setForm({ ...form, annee_scolaire: e.target.value })} className={inputClass} placeholder="2025-2026" />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-muted transition-colors">Annuler</button>
            <button onClick={handleSave} className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">{editing ? "Modifier" : "Ajouter"}</button>
          </div>
        </div>
      </CrudModal>

      <DeleteConfirm open={!!deleting} onClose={() => setDeleting(null)} onConfirm={handleDelete} name={deleting?.nom || ""} />
    </div>
  );
};

export default Classes;
