import { Users, GraduationCap, BookOpen, TrendingUp, DollarSign, UserCog, Layers } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, Legend } from "recharts";
import StatCard from "@/components/StatCard";
import { useData } from "@/contexts/DataContext";
import { useAuth } from "@/contexts/AuthContext";
import { useMemo } from "react";

const COLORS = ["hsl(var(--primary))", "hsl(var(--accent))", "#22c55e", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4", "#ec4899"];

const Dashboard = () => {
  const { students, teachers, courses, personnel, transactions, classes, grades } = useData();
  const { user } = useAuth();

  const totalRecettes = transactions.filter((t) => t.type === "recette" || t.type === "frais").reduce((a, b) => a + b.montant, 0);
  const totalDepenses = transactions.filter((t) => t.type === "depense" || t.type === "salaire").reduce((a, b) => a + b.montant, 0);

  // Students per class chart data
  const studentsPerClass = useMemo(() => {
    const map: Record<string, number> = {};
    students.forEach(s => { map[s.classe] = (map[s.classe] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [students]);

  // Gender distribution
  const genderData = useMemo(() => {
    const m = students.filter(s => s.sexe === "M").length;
    const f = students.filter(s => s.sexe === "F").length;
    return [{ name: "Garçons", value: m }, { name: "Filles", value: f }];
  }, [students]);

  // Financial by type
  const financeByType = useMemo(() => {
    const map: Record<string, number> = {};
    transactions.forEach(t => { map[t.type] = (map[t.type] || 0) + t.montant; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [transactions]);

  // Average grades per class
  const gradesPerClass = useMemo(() => {
    const classMap: Record<string, { total: number; count: number }> = {};
    grades.forEach(g => {
      const s = students.find(st => st.id === g.eleve_id);
      if (s) {
        if (!classMap[s.classe]) classMap[s.classe] = { total: 0, count: 0 };
        classMap[s.classe].total += g.note;
        classMap[s.classe].count += 1;
      }
    });
    return Object.entries(classMap).map(([name, v]) => ({ name, moyenne: Number((v.total / v.count).toFixed(1)) })).sort((a, b) => a.name.localeCompare(b.name));
  }, [grades, students]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Administration</h1>
        <p className="text-sm text-muted-foreground">
          Bienvenue, <span className="font-semibold capitalize">{user?.fullName}</span> — Complexe Scolaire TURUNGA
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {(user?.role === "admin" || user?.role === "secretaire") && (
          <>
            <StatCard title="Total Élèves" value={students.length} icon={Users} variant="default" />
            <StatCard title="Enseignants" value={teachers.length} icon={GraduationCap} variant="accent" />
            <StatCard title="Cours" value={courses.length} icon={BookOpen} variant="info" />
            <StatCard title="Classes" value={classes.length} icon={Layers} variant="success" />
          </>
        )}
        {(user?.role === "admin") && (
          <StatCard title="Personnel" value={personnel.length} icon={UserCog} variant="success" />
        )}
        {(user?.role === "admin" || user?.role === "comptable") && (
          <>
            <StatCard title="Recettes" value={`${totalRecettes.toLocaleString()} FC`} icon={TrendingUp} variant="success" />
            <StatCard title="Dépenses" value={`${totalDepenses.toLocaleString()} FC`} icon={DollarSign} variant="default" />
          </>
        )}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {(user?.role === "admin" || user?.role === "secretaire") && studentsPerClass.length > 0 && (
          <div className="rounded-xl border border-border bg-card p-6 animate-fade-in">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Élèves par classe</h2>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={studentsPerClass}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="value" name="Élèves" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {(user?.role === "admin" || user?.role === "secretaire") && genderData.some(d => d.value > 0) && (
          <div className="rounded-xl border border-border bg-card p-6 animate-fade-in">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Répartition par sexe</h2>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={genderData} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}>
                  {genderData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        {(user?.role === "admin" || user?.role === "secretaire") && gradesPerClass.length > 0 && (
          <div className="rounded-xl border border-border bg-card p-6 animate-fade-in">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Moyenne par classe</h2>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={gradesPerClass}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis domain={[0, 20]} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }} />
                <Line type="monotone" dataKey="moyenne" name="Moyenne" stroke="#22c55e" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {(user?.role === "admin" || user?.role === "comptable") && financeByType.length > 0 && (
          <div className="rounded-xl border border-border bg-card p-6 animate-fade-in">
            <h2 className="mb-4 text-lg font-semibold text-foreground">Finances par type</h2>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={financeByType} cx="50%" cy="50%" outerRadius={100} dataKey="value" label={({ name, value }) => `${name}: ${value.toLocaleString()} FC`}>
                  {financeByType.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v: number) => `${v.toLocaleString()} FC`} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      {(user?.role === "admin" || user?.role === "secretaire") && (
        <div className="rounded-xl border border-border bg-card p-6 animate-fade-in">
          <h2 className="mb-4 text-lg font-semibold text-foreground">Derniers élèves inscrits</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left">
                  <th className="pb-3 font-semibold text-muted-foreground">Nom complet</th>
                  <th className="pb-3 font-semibold text-muted-foreground">Classe</th>
                  <th className="pb-3 font-semibold text-muted-foreground">Sexe</th>
                </tr>
              </thead>
              <tbody>
                {students.slice(-5).reverse().map((s) => (
                  <tr key={s.id} className="border-b border-border/50 last:border-0">
                    <td className="py-3 font-medium text-foreground">{s.nom}</td>
                    <td className="py-3 text-muted-foreground">{s.classe}</td>
                    <td className="py-3 text-muted-foreground">{s.sexe}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
