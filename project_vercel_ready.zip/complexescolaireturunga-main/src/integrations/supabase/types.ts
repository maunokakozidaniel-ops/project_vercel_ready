export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      classes: {
        Row: {
          annee_scolaire: string
          capacite: number
          created_at: string
          id: string
          nom: string
          promotion_order: number
          school_year_id: string | null
          section: string
          titulaire: string
          updated_at: string
        }
        Insert: {
          annee_scolaire?: string
          capacite?: number
          created_at?: string
          id?: string
          nom: string
          promotion_order?: number
          school_year_id?: string | null
          section?: string
          titulaire?: string
          updated_at?: string
        }
        Update: {
          annee_scolaire?: string
          capacite?: number
          created_at?: string
          id?: string
          nom?: string
          promotion_order?: number
          school_year_id?: string | null
          section?: string
          titulaire?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "classes_school_year_id_fkey"
            columns: ["school_year_id"]
            isOneToOne: false
            referencedRelation: "school_years"
            referencedColumns: ["id"]
          },
        ]
      }
      courses: {
        Row: {
          classe: string
          coefficient: number
          created_at: string
          enseignant: string
          id: string
          max_note: number
          nom: string
          updated_at: string
        }
        Insert: {
          classe?: string
          coefficient?: number
          created_at?: string
          enseignant?: string
          id?: string
          max_note?: number
          nom: string
          updated_at?: string
        }
        Update: {
          classe?: string
          coefficient?: number
          created_at?: string
          enseignant?: string
          id?: string
          max_note?: number
          nom?: string
          updated_at?: string
        }
        Relationships: []
      }
      fee_structures: {
        Row: {
          amount: number
          class_id: string | null
          created_at: string
          id: string
          is_mandatory: boolean
          label: string
          notes: string
          payment_type_id: string | null
          school_year_id: string
          updated_at: string
        }
        Insert: {
          amount?: number
          class_id?: string | null
          created_at?: string
          id?: string
          is_mandatory?: boolean
          label: string
          notes?: string
          payment_type_id?: string | null
          school_year_id: string
          updated_at?: string
        }
        Update: {
          amount?: number
          class_id?: string | null
          created_at?: string
          id?: string
          is_mandatory?: boolean
          label?: string
          notes?: string
          payment_type_id?: string | null
          school_year_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fee_structures_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fee_structures_payment_type_id_fkey"
            columns: ["payment_type_id"]
            isOneToOne: false
            referencedRelation: "payment_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fee_structures_school_year_id_fkey"
            columns: ["school_year_id"]
            isOneToOne: false
            referencedRelation: "school_years"
            referencedColumns: ["id"]
          },
        ]
      }
      grades: {
        Row: {
          cours_id: string
          created_at: string
          eleve_id: string
          id: string
          note: number
          periode: string
          school_year_id: string | null
          updated_at: string
        }
        Insert: {
          cours_id: string
          created_at?: string
          eleve_id: string
          id?: string
          note?: number
          periode: string
          school_year_id?: string | null
          updated_at?: string
        }
        Update: {
          cours_id?: string
          created_at?: string
          eleve_id?: string
          id?: string
          note?: number
          periode?: string
          school_year_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "grades_cours_id_fkey"
            columns: ["cours_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_eleve_id_fkey"
            columns: ["eleve_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "grades_school_year_id_fkey"
            columns: ["school_year_id"]
            isOneToOne: false
            referencedRelation: "school_years"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_types: {
        Row: {
          color: string
          created_at: string
          default_amount: number
          direction: string
          id: string
          key: string
          label: string
        }
        Insert: {
          color?: string
          created_at?: string
          default_amount?: number
          direction?: string
          id?: string
          key: string
          label: string
        }
        Update: {
          color?: string
          created_at?: string
          default_amount?: number
          direction?: string
          id?: string
          key?: string
          label?: string
        }
        Relationships: []
      }
      personnel: {
        Row: {
          adresse: string
          created_at: string
          date_naissance: string
          departement: string
          fonction: string
          genre: string
          id: string
          nom: string
          salaire: number
          statut: string
          tel: string
          updated_at: string
        }
        Insert: {
          adresse?: string
          created_at?: string
          date_naissance?: string
          departement?: string
          fonction?: string
          genre?: string
          id?: string
          nom: string
          salaire?: number
          statut?: string
          tel?: string
          updated_at?: string
        }
        Update: {
          adresse?: string
          created_at?: string
          date_naissance?: string
          departement?: string
          fonction?: string
          genre?: string
          id?: string
          nom?: string
          salaire?: number
          statut?: string
          tel?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          full_name: string
          id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          full_name?: string
          id?: string
          user_id: string
        }
        Update: {
          created_at?: string
          full_name?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      school_settings: {
        Row: {
          adresse: string
          annee_scolaire: string
          directeur: string
          email: string
          id: string
          nom: string
          telephone: string
          updated_at: string
        }
        Insert: {
          adresse?: string
          annee_scolaire?: string
          directeur?: string
          email?: string
          id?: string
          nom?: string
          telephone?: string
          updated_at?: string
        }
        Update: {
          adresse?: string
          annee_scolaire?: string
          directeur?: string
          email?: string
          id?: string
          nom?: string
          telephone?: string
          updated_at?: string
        }
        Relationships: []
      }
      school_years: {
        Row: {
          created_at: string
          end_date: string
          id: string
          is_active: boolean
          is_archived: boolean
          name: string
          passing_score: number
          start_date: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          end_date: string
          id?: string
          is_active?: boolean
          is_archived?: boolean
          name: string
          passing_score?: number
          start_date: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          end_date?: string
          id?: string
          is_active?: boolean
          is_archived?: boolean
          name?: string
          passing_score?: number
          start_date?: string
          updated_at?: string
        }
        Relationships: []
      }
      student_history: {
        Row: {
          average: number | null
          class_id: string | null
          created_at: string
          id: string
          next_class_name: string
          notes: string
          school_year_id: string | null
          status: string
          student_id: string
        }
        Insert: {
          average?: number | null
          class_id?: string | null
          created_at?: string
          id?: string
          next_class_name?: string
          notes?: string
          school_year_id?: string | null
          status: string
          student_id: string
        }
        Update: {
          average?: number | null
          class_id?: string | null
          created_at?: string
          id?: string
          next_class_name?: string
          notes?: string
          school_year_id?: string | null
          status?: string
          student_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "student_history_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_history_school_year_id_fkey"
            columns: ["school_year_id"]
            isOneToOne: false
            referencedRelation: "school_years"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "student_history_student_id_fkey"
            columns: ["student_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
        ]
      }
      students: {
        Row: {
          adresse: string
          classe: string
          created_at: string
          current_class_id: string | null
          id: string
          matricule: string | null
          naissance: string
          nom: string
          parent: string
          school_year_id: string | null
          sexe: string
          tel_parent: string
          updated_at: string
        }
        Insert: {
          adresse?: string
          classe: string
          created_at?: string
          current_class_id?: string | null
          id?: string
          matricule?: string | null
          naissance: string
          nom: string
          parent?: string
          school_year_id?: string | null
          sexe: string
          tel_parent?: string
          updated_at?: string
        }
        Update: {
          adresse?: string
          classe?: string
          created_at?: string
          current_class_id?: string | null
          id?: string
          matricule?: string | null
          naissance?: string
          nom?: string
          parent?: string
          school_year_id?: string | null
          sexe?: string
          tel_parent?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "students_current_class_id_fkey"
            columns: ["current_class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "students_school_year_id_fkey"
            columns: ["school_year_id"]
            isOneToOne: false
            referencedRelation: "school_years"
            referencedColumns: ["id"]
          },
        ]
      }
      teachers: {
        Row: {
          adresse: string
          classes: string
          created_at: string
          genre: string
          id: string
          matiere: string
          nom: string
          salaire: number
          statut: string
          tel: string
          updated_at: string
        }
        Insert: {
          adresse?: string
          classes?: string
          created_at?: string
          genre?: string
          id?: string
          matiere: string
          nom: string
          salaire?: number
          statut?: string
          tel?: string
          updated_at?: string
        }
        Update: {
          adresse?: string
          classes?: string
          created_at?: string
          genre?: string
          id?: string
          matiere?: string
          nom?: string
          salaire?: number
          statut?: string
          tel?: string
          updated_at?: string
        }
        Relationships: []
      }
      timetables: {
        Row: {
          classe: string
          cours: string
          created_at: string
          enseignant: string
          heure_debut: string
          heure_fin: string
          id: string
          jour: string
          salle: string
          updated_at: string
        }
        Insert: {
          classe: string
          cours: string
          created_at?: string
          enseignant?: string
          heure_debut: string
          heure_fin: string
          id?: string
          jour: string
          salle?: string
          updated_at?: string
        }
        Update: {
          classe?: string
          cours?: string
          created_at?: string
          enseignant?: string
          heure_debut?: string
          heure_fin?: string
          id?: string
          jour?: string
          salle?: string
          updated_at?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          created_at: string
          date: string
          description: string
          eleve_id: string | null
          id: string
          montant: number
          personnel_id: string | null
          school_year_id: string | null
          type: string
        }
        Insert: {
          created_at?: string
          date: string
          description?: string
          eleve_id?: string | null
          id?: string
          montant?: number
          personnel_id?: string | null
          school_year_id?: string | null
          type: string
        }
        Update: {
          created_at?: string
          date?: string
          description?: string
          eleve_id?: string | null
          id?: string
          montant?: number
          personnel_id?: string | null
          school_year_id?: string | null
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_eleve_id_fkey"
            columns: ["eleve_id"]
            isOneToOne: false
            referencedRelation: "students"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_personnel_id_fkey"
            columns: ["personnel_id"]
            isOneToOne: false
            referencedRelation: "personnel"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_school_year_id_fkey"
            columns: ["school_year_id"]
            isOneToOne: false
            referencedRelation: "school_years"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      apply_student_promotions: {
        Args: {
          _passing_score?: number
          _source_school_year_id: string
          _target_school_year_id: string
        }
        Returns: number
      }
      archive_school_year: {
        Args: { _archive?: boolean; _school_year_id: string }
        Returns: undefined
      }
      copy_school_year_data: {
        Args: {
          _copy_classes?: boolean
          _copy_courses?: boolean
          _copy_fees?: boolean
          _copy_students?: boolean
          _source_id: string
          _target_id: string
        }
        Returns: number
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      preview_student_promotions: {
        Args: {
          _passing_score?: number
          _source_school_year_id: string
          _target_school_year_id: string
        }
        Returns: {
          average_percent: number
          current_class_id: string
          current_class_name: string
          next_class_id: string
          next_class_name: string
          status: string
          student_id: string
          student_name: string
        }[]
      }
      set_active_school_year: {
        Args: { _school_year_id: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "secretaire" | "comptable"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "secretaire", "comptable"],
    },
  },
} as const
