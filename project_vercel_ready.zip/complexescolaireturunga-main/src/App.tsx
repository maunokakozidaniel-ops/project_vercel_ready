import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { DataProvider } from "@/contexts/DataContext";
import { SchoolYearProvider } from "@/contexts/SchoolYearContext";
import SchoolYears from "./pages/SchoolYears";
import AppLayout from "./components/AppLayout";
import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import Teachers from "./pages/Teachers";
import Classes from "./pages/Classes";
import Courses from "./pages/Courses";
import Bulletins from "./pages/Bulletins";
import Notes from "./pages/Notes";
import Parametres from "./pages/Parametres";
import Comptabilite from "./pages/Comptabilite";
import PersonnelPage from "./pages/Personnel";
import TimetablePage from "./pages/Timetable";
import WhatsAppPage from "./pages/WhatsApp";
import Inscription from "./pages/Inscription";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const ProtectedRoutes = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="text-center">
          <div className="mx-auto mb-4 h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  return (
    <SchoolYearProvider>
      <DataProvider>
      <Routes>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Dashboard />} />
          {(user.role === "admin" || user.role === "secretaire" || user.role === "comptable") && (
            <>
              <Route path="/eleves" element={<Students />} />
              <Route path="/enseignants" element={<Teachers />} />
              <Route path="/classes" element={<Classes />} />
            </>
          )}
          {(user.role === "admin" || user.role === "secretaire") && (
            <>
              <Route path="/inscription" element={<Inscription />} />
              <Route path="/cours" element={<Courses />} />
              <Route path="/bulletins" element={<Bulletins />} />
              <Route path="/emploi-du-temps" element={<TimetablePage />} />
              <Route path="/notes" element={<Notes />} />
              <Route path="/whatsapp" element={<WhatsAppPage />} />
            </>
          )}
          {user.role === "admin" && (
            <>
              <Route path="/personnel" element={<PersonnelPage />} />
              <Route path="/parametres" element={<Parametres />} />
              <Route path="/annees-scolaires" element={<SchoolYears />} />
            </>
          )}
          {(user.role === "admin" || user.role === "comptable") && (
            <>
              <Route path="/comptabilite" element={<Comptabilite />} />
              <Route path="/personnel" element={<PersonnelPage />} />
            </>
          )}
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </DataProvider>
    </SchoolYearProvider>
  );
};

const AppContent = () => {
  const { user, loading } = useAuth();

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={!loading && user ? <Navigate to="/" replace /> : <Login />} />
        <Route path="/*" element={<ProtectedRoutes />} />
      </Routes>
    </BrowserRouter>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
