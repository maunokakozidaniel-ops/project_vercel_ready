import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables, TablesInsert } from "@/integrations/supabase/types";
import { useAuth } from "@/contexts/AuthContext";
import { useSchoolYear } from "@/contexts/SchoolYearContext";

export type Student = Tables<"students">;
export type Teacher = Tables<"teachers">;
export type Course = Tables<"courses">;
export type PersonnelType = Tables<"personnel">;
export type Transaction = Tables<"transactions">;
export type Grade = Tables<"grades">;
export type SchoolSettings = Tables<"school_settings">;
export type ClassType = Tables<"classes">;
export type Timetable = Tables<"timetables">;
type StudentInsert = TablesInsert<"students">;
type TeacherInsert = TablesInsert<"teachers">;
type CourseInsert = TablesInsert<"courses">;
type PersonnelInsert = TablesInsert<"personnel">;
type TransactionInsert = TablesInsert<"transactions">;
type GradeInsert = TablesInsert<"grades">;
type ClassInsert = TablesInsert<"classes">;
type TimetableInsert = TablesInsert<"timetables">;

interface DataContextType {
  students: Student[];
  addStudent: (s: StudentInsert) => Promise<void>;
  updateStudent: (s: Student) => Promise<void>;
  deleteStudent: (id: string) => Promise<void>;

  teachers: Teacher[];
  addTeacher: (t: TeacherInsert) => Promise<void>;
  updateTeacher: (t: Teacher) => Promise<void>;
  deleteTeacher: (id: string) => Promise<void>;

  courses: Course[];
  addCourse: (c: CourseInsert) => Promise<void>;
  updateCourse: (c: Course) => Promise<void>;
  deleteCourse: (id: string) => Promise<void>;

  personnel: PersonnelType[];
  addPersonnel: (p: PersonnelInsert) => Promise<void>;
  updatePersonnel: (p: PersonnelType) => Promise<void>;
  deletePersonnel: (id: string) => Promise<void>;

  transactions: Transaction[];
  addTransaction: (t: TransactionInsert) => Promise<void>;
  updateTransaction: (t: Transaction) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;

  grades: Grade[];
  addGrade: (g: GradeInsert) => Promise<void>;
  updateGrade: (g: Grade) => Promise<void>;
  deleteGrade: (id: string) => Promise<void>;

  classes: ClassType[];
  addClass: (c: ClassInsert) => Promise<void>;
  updateClass: (c: ClassType) => Promise<void>;
  deleteClass: (id: string) => Promise<void>;

  timetables: Timetable[];
  addTimetable: (t: TimetableInsert) => Promise<void>;
  updateTimetable: (t: Timetable) => Promise<void>;
  deleteTimetable: (id: string) => Promise<void>;

  settings: SchoolSettings | null;
  updateSettings: (s: Partial<SchoolSettings>) => Promise<void>;

  loading: boolean;
  refresh: () => Promise<void>;
}

const DataContext = createContext<DataContextType | null>(null);

export const DataProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const { selectedYearId } = useSchoolYear();
  const [students, setStudents] = useState<Student[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [personnel, setPersonnel] = useState<PersonnelType[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [classes, setClasses] = useState<ClassType[]>([]);
  const [timetables, setTimetables] = useState<Timetable[]>([]);
  const [settings, setSettings] = useState<SchoolSettings | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    if (!user) {
      setStudents([]); setTeachers([]); setCourses([]); setPersonnel([]);
      setTransactions([]); setGrades([]); setSettings(null);
      setClasses([]); setTimetables([]);
      setLoading(false);
      return;
    }

    setLoading(true);

    const canReadPersonnel = user.role === "admin" || user.role === "comptable";
    const canReadTransactions = user.role === "admin" || user.role === "comptable";
    const canReadGrades = user.role === "admin" || user.role === "secretaire";
    const canReadTimetables = user.role === "admin" || user.role === "secretaire";

    // Strict year filter: each school year sees only its own data
    const yearFilter = <T extends { eq: Function }>(q: T) =>
      selectedYearId ? (q.eq("school_year_id", selectedYearId) as T) : q;

    const studentsQ = yearFilter(supabase.from("students").select("*").order("nom") as any);
    const transactionsQ = canReadTransactions
      ? yearFilter(supabase.from("transactions").select("*").order("date", { ascending: false }) as any)
      : Promise.resolve({ data: [] as Transaction[] });
    const gradesQ = canReadGrades
      ? yearFilter(supabase.from("grades").select("*") as any)
      : Promise.resolve({ data: [] as Grade[] });
    const classesQ = yearFilter(supabase.from("classes").select("*").order("nom") as any);

    const [s, t, c, p, tr, g, st, cl, tt] = await Promise.all([
      studentsQ,
      supabase.from("teachers").select("*").order("nom"),
      supabase.from("courses").select("*").order("nom"),
      canReadPersonnel ? supabase.from("personnel").select("*").order("nom") : Promise.resolve({ data: [] as PersonnelType[] }),
      transactionsQ,
      gradesQ,
      supabase.from("school_settings").select("*").limit(1).maybeSingle(),
      classesQ,
      canReadTimetables ? supabase.from("timetables").select("*").order("jour") : Promise.resolve({ data: [] as Timetable[] }),
    ]);

    setStudents(s.data || []);
    setTeachers(t.data || []);
    setCourses(c.data || []);
    setPersonnel(p.data || []);
    setTransactions(tr.data || []);
    setGrades(g.data || []);
    setSettings(st.data ?? null);
    setClasses(cl.data || []);
    setTimetables(tt.data || []);
    setLoading(false);
  }, [user, selectedYearId]);

  useEffect(() => { void fetchAll(); }, [fetchAll]);

  // Students
  const addStudent = async (s: StudentInsert) => {
    const payload = { ...s, school_year_id: s.school_year_id ?? selectedYearId };
    const { data } = await supabase.from("students").insert(payload).select().single();
    if (data) setStudents((prev) => [...prev, data]);
  };
  const updateStudent = async (s: Student) => {
    const { id, created_at, updated_at, ...rest } = s;
    const { data } = await supabase.from("students").update(rest).eq("id", id).select().single();
    if (data) setStudents((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deleteStudent = async (id: string) => {
    await supabase.from("students").delete().eq("id", id);
    setStudents((prev) => prev.filter((x) => x.id !== id));
  };

  // Teachers
  const addTeacher = async (t: TeacherInsert) => {
    const { data } = await supabase.from("teachers").insert(t).select().single();
    if (data) setTeachers((prev) => [...prev, data]);
  };
  const updateTeacher = async (t: Teacher) => {
    const { id, created_at, updated_at, ...rest } = t;
    const { data } = await supabase.from("teachers").update(rest).eq("id", id).select().single();
    if (data) setTeachers((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deleteTeacher = async (id: string) => {
    await supabase.from("teachers").delete().eq("id", id);
    setTeachers((prev) => prev.filter((x) => x.id !== id));
  };

  // Courses
  const addCourse = async (c: CourseInsert) => {
    const { data } = await supabase.from("courses").insert(c).select().single();
    if (data) setCourses((prev) => [...prev, data]);
  };
  const updateCourse = async (c: Course) => {
    const { id, created_at, updated_at, ...rest } = c;
    const { data } = await supabase.from("courses").update(rest).eq("id", id).select().single();
    if (data) setCourses((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deleteCourse = async (id: string) => {
    await supabase.from("courses").delete().eq("id", id);
    setCourses((prev) => prev.filter((x) => x.id !== id));
  };

  // Personnel
  const addPersonnel = async (p: PersonnelInsert) => {
    const { data } = await supabase.from("personnel").insert(p).select().single();
    if (data) setPersonnel((prev) => [...prev, data]);
  };
  const updatePersonnel = async (p: PersonnelType) => {
    const { id, created_at, updated_at, ...rest } = p;
    const { data } = await supabase.from("personnel").update(rest).eq("id", id).select().single();
    if (data) setPersonnel((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deletePersonnel = async (id: string) => {
    await supabase.from("personnel").delete().eq("id", id);
    setPersonnel((prev) => prev.filter((x) => x.id !== id));
  };

  // Transactions
  const addTransaction = async (t: TransactionInsert) => {
    const payload = { ...t, school_year_id: t.school_year_id ?? selectedYearId };
    const { data } = await supabase.from("transactions").insert(payload).select().single();
    if (data) setTransactions((prev) => [data, ...prev]);
  };
  const updateTransaction = async (t: Transaction) => {
    const { id, created_at, ...rest } = t;
    const { data } = await supabase.from("transactions").update(rest).eq("id", id).select().single();
    if (data) setTransactions((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deleteTransaction = async (id: string) => {
    await supabase.from("transactions").delete().eq("id", id);
    setTransactions((prev) => prev.filter((x) => x.id !== id));
  };

  // Grades
  const addGrade = async (g: GradeInsert) => {
    const payload = { ...g, school_year_id: g.school_year_id ?? selectedYearId };
    const { data } = await supabase.from("grades").insert(payload).select().single();
    if (data) setGrades((prev) => [...prev, data]);
  };
  const updateGrade = async (g: Grade) => {
    const { id, created_at, updated_at, ...rest } = g;
    const { data } = await supabase.from("grades").update(rest).eq("id", id).select().single();
    if (data) setGrades((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deleteGrade = async (id: string) => {
    await supabase.from("grades").delete().eq("id", id);
    setGrades((prev) => prev.filter((x) => x.id !== id));
  };

  // Classes
  const addClass = async (c: ClassInsert) => {
    const payload = { ...c, school_year_id: c.school_year_id ?? selectedYearId };
    const { data, error } = await supabase.from("classes").insert(payload).select().single();
    if (error) { console.error("addClass error:", error); return; }
    if (data) setClasses((prev) => [...prev, data]);
  };
  const updateClass = async (c: ClassType) => {
    const { id, created_at, updated_at, ...rest } = c;
    const { data, error } = await supabase.from("classes").update(rest).eq("id", id).select().single();
    if (error) { console.error("updateClass error:", error); return; }
    if (data) setClasses((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deleteClass = async (id: string) => {
    const { error } = await supabase.from("classes").delete().eq("id", id);
    if (error) { console.error("deleteClass error:", error); return; }
    setClasses((prev) => prev.filter((x) => x.id !== id));
  };

  // Timetables
  const addTimetable = async (t: TimetableInsert) => {
    const { data } = await supabase.from("timetables").insert(t).select().single();
    if (data) setTimetables((prev) => [...prev, data]);
  };
  const updateTimetable = async (t: Timetable) => {
    const { id, created_at, updated_at, ...rest } = t;
    const { data } = await supabase.from("timetables").update(rest).eq("id", id).select().single();
    if (data) setTimetables((prev) => prev.map((x) => (x.id === id ? data : x)));
  };
  const deleteTimetable = async (id: string) => {
    await supabase.from("timetables").delete().eq("id", id);
    setTimetables((prev) => prev.filter((x) => x.id !== id));
  };

  // Settings
  const updateSettings = async (s: Partial<SchoolSettings>) => {
    if (!settings) return;
    const { data } = await supabase.from("school_settings").update(s).eq("id", settings.id).select().single();
    if (data) setSettings(data);
  };

  return (
    <DataContext.Provider
      value={{
        students, addStudent, updateStudent, deleteStudent,
        teachers, addTeacher, updateTeacher, deleteTeacher,
        courses, addCourse, updateCourse, deleteCourse,
        personnel, addPersonnel, updatePersonnel, deletePersonnel,
        transactions, addTransaction, updateTransaction, deleteTransaction,
        grades, addGrade, updateGrade, deleteGrade,
        classes, addClass, updateClass, deleteClass,
        timetables, addTimetable, updateTimetable, deleteTimetable,
        settings, updateSettings,
        loading, refresh: fetchAll,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error("useData must be used within DataProvider");
  return ctx;
};
