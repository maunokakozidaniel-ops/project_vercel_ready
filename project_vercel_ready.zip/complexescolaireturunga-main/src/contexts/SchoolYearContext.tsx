import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { useAuth } from "@/contexts/AuthContext";

export type SchoolYear = Tables<"school_years">;

interface SchoolYearContextType {
  years: SchoolYear[];
  activeYear: SchoolYear | null;
  selectedYearId: string | null;
  setSelectedYearId: (id: string | null) => void;
  loading: boolean;
  refresh: () => Promise<void>;
}

const SchoolYearContext = createContext<SchoolYearContextType | null>(null);

export const SchoolYearProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useAuth();
  const [years, setYears] = useState<SchoolYear[]>([]);
  const [selectedYearId, setSelectedYearIdState] = useState<string | null>(
    () => localStorage.getItem("selectedSchoolYearId")
  );
  const [loading, setLoading] = useState(true);

  const setSelectedYearId = (id: string | null) => {
    setSelectedYearIdState(id);
    if (id) localStorage.setItem("selectedSchoolYearId", id);
    else localStorage.removeItem("selectedSchoolYearId");
  };

  const fetchYears = useCallback(async () => {
    if (!user) { setYears([]); setLoading(false); return; }
    setLoading(true);
    const { data } = await supabase
      .from("school_years")
      .select("*")
      .order("start_date", { ascending: false });
    const list = data || [];
    setYears(list);
    if (!selectedYearId || !list.find((y) => y.id === selectedYearId)) {
      const active = list.find((y) => y.is_active) || list[0];
      if (active) setSelectedYearId(active.id);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { void fetchYears(); }, [fetchYears]);

  const activeYear = years.find((y) => y.is_active) || null;

  return (
    <SchoolYearContext.Provider value={{ years, activeYear, selectedYearId, setSelectedYearId, loading, refresh: fetchYears }}>
      {children}
    </SchoolYearContext.Provider>
  );
};

export const useSchoolYear = () => {
  const ctx = useContext(SchoolYearContext);
  if (!ctx) throw new Error("useSchoolYear must be used within SchoolYearProvider");
  return ctx;
};
