import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Session, User as SupaUser } from "@supabase/supabase-js";

export type UserRole = "admin" | "secretaire" | "comptable";

interface User {
  id: string;
  email: string;
  role: UserRole;
  fullName: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<string | null>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

async function fetchUserRole(userId: string): Promise<UserRole | null> {
  const { data } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .maybeSingle();
  return data?.role ?? null;
}

async function fetchProfile(userId: string): Promise<string> {
  const { data } = await supabase
    .from("profiles")
    .select("full_name")
    .eq("user_id", userId)
    .maybeSingle();
  return data?.full_name || "";
}

async function buildUser(su: SupaUser): Promise<User | null> {
  const [role, fullName] = await Promise.all([
    fetchUserRole(su.id),
    fetchProfile(su.id),
  ]);
  if (!role) return null;
  return { id: su.id, email: su.email || "", role, fullName: fullName || su.email || "" };
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    let requestId = 0;

    const syncSession = async (session: Session | null) => {
      const currentRequestId = ++requestId;

      try {
        if (!session?.user) {
          if (mounted) setUser(null);
          return;
        }

        const nextUser = await buildUser(session.user);
        if (mounted && currentRequestId === requestId) {
          setUser(nextUser);
        }
      } catch (error) {
        console.error("auth session sync error:", error);
        if (mounted && currentRequestId === requestId) {
          setUser(null);
        }
      } finally {
        if (mounted && currentRequestId === requestId) {
          setLoading(false);
        }
      }
    };

    setLoading(true);
    void supabase.auth.getSession().then(({ data: { session } }) => {
      void syncSession(session);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      window.setTimeout(() => {
        void syncSession(session);
      }, 0);
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const login = async (email: string, password: string): Promise<string | null> => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return error.message;
    return null;
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
